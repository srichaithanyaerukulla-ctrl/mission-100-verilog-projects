# Project 009 — MOSFET as a Digital Switch

**Mission 100 Verilog Projects · Semiconductor Fundamentals · Project 009/100**

## Goal
Implement two practical switching circuits: an **NMOS low-side switch** and a **PMOS high-side switch**. Observe their load voltages in SPICE and implement a **digital-only functional abstraction** in Verilog.

## What you learn
1. How NMOS low-side and PMOS high-side switching differ.
2. Why gate-to-source voltage (`VGS`) rather than absolute gate voltage determines conduction.
3. Why a pull-down/pull-up is needed for a reliable OFF state.
4. How to drive an output load and measure transient switching in SPICE.
5. How to test functional switching behavior in Verilog without claiming it is transistor-level simulation.

## Circuit A: NMOS low-side switch

```
+5 V --- 1 kΩ load --- D  NMOS  S --- GND
                         G <- 0/5 V control (through 100 Ω)
                         G --- 100 kΩ --- GND
```

`control = 1` -> NMOS ON -> drain/load-low node approximately 0 V -> load energized.
`control = 0` -> NMOS OFF -> drain/load-low node approximately +5 V -> load de-energized.

## Circuit B: PMOS high-side switch

```
+5 V --- S  PMOS  D --- 1 kΩ load --- GND
           G <- 5/0 V control (through 100 Ω)
           G --- 100 kΩ --- +5 V
```

`control = 0` -> PMOS ON -> drain/load-high node approximately +5 V -> load energized.
`control = 1` -> PMOS OFF -> drain/load-high node approximately 0 V -> load de-energized.

**Note:** PMOS control uses 0 V and +5 V levels; its ON command is active-low.

## File map
- `spice/nmos_low_side_switch.cir` — NMOS transient switching circuit.
- `spice/pmos_high_side_switch.cir` — PMOS transient switching circuit.
- `verilog/mosfet_digital_switch.v` — functional switch model (not an analog transistor model).
- `tb/tb_mosfet_digital_switch.v` — self-checking testbench.
- `docs/design-notes.md` — calculations, circuit design and safety limits.
- `simulation/results-template.md` — fill in after actual simulator runs.
- `.gitignore` — generated output exclusions.

## Run SPICE
Requires `ngspice`. Run from the project root:
```sh
ngspice -b spice/nmos_low_side_switch.cir
ngspice -b spice/pmos_high_side_switch.cir
```
The netlists write `nmos_switch_transient.csv` and `pmos_switch_transient.csv` to the current working directory. Each contains transient waveforms for gate, load node, and supply current; inspect the headers and sign convention in your ngspice version.

## Run Verilog
Requires `iverilog` and `vvp`:
```sh
iverilog -g2012 -s tb_mosfet_digital_switch -o switch_sim verilog/mosfet_digital_switch.v tb/tb_mosfet_digital_switch.v
vvp switch_sim
```
The testbench checks NMOS active-high and PMOS active-low switching and writes a VCD waveform. It is a functional digital model, not a MOSFET electrical simulation.

## GitHub path
`mission-100-verilog-projects/01-semiconductor-fundamentals/project-009-mosfet-digital-switch/`

## Status
**Pending verification:** these simulations are provided as runnable source files, but no actual simulator execution is claimed here.
