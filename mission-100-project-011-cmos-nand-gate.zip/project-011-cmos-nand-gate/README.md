# Project 011 — CMOS NAND Gate Design and Analysis

**Mission 100 Verilog Projects · Semiconductor-to-VLSI Journey · Project 011/100**

## Objective
CMOS NAND Gate Design and Analysis: implement the design and verify its behavior with a self-checking Verilog testbench.

## Theory
A CMOS NAND implements Y = ~(A & B). Two PMOS transistors are in parallel in the pull-up network, so either LOW input can pull the output HIGH. Two NMOS transistors are in series in the pull-down network, so the output is pulled LOW only when both inputs are HIGH. This complementary topology has low ideal static power in stable states except leakage. Series NMOS resistance and transistor sizing affect real delay and output drive.

## Design approach
The RTL models functional logic or storage. It does not automatically reproduce analog transistor behavior, power, propagation delay, or metastability. Where a SPICE netlist is provided, it uses generic educational MOSFET models rather than a foundry-calibrated process model.

## Files
- `README.md` — theory and run instructions.
- `verilog/cmos_nand_gate.v` — Verilog implementation.
- `tb/tb_cmos_nand_gate.v` — self-checking testbench.
- `spice/cmos_nand_gate.cir` — illustrative transistor-level SPICE circuit.\n- `docs/design-notes.md` — design considerations.
- `simulation/results-template.md` — record actual results.

## Run Verilog
```sh
iverilog -g2012 -s tb_cmos_nand_gate -o sim_out verilog/cmos_nand_gate.v tb/tb_cmos_nand_gate.v
vvp sim_out
```

## Run SPICE
```sh
ngspice -b spice/cmos_nand_gate.cir
```
Inspect the log and generated CSV. Simulator syntax and model behavior can vary by version.

## Verification status
**Pending verification.** The files are packaged for execution, but no test or SPICE result is claimed until you run the simulator and inspect its output.
