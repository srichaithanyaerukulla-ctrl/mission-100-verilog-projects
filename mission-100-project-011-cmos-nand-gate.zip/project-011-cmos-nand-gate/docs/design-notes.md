# Design Notes — Project 011

A CMOS NAND implements Y = ~(A & B). Two PMOS transistors are in parallel in the pull-up network, so either LOW input can pull the output HIGH. Two NMOS transistors are in series in the pull-down network, so the output is pulled LOW only when both inputs are HIGH. This complementary topology has low ideal static power in stable states except leakage. Series NMOS resistance and transistor sizing affect real delay and output drive.

## Validation
- Run the included testbench.
- Review warnings and confirm expected state/logic transitions.
- For SPICE projects, inspect waveform and model assumptions.
