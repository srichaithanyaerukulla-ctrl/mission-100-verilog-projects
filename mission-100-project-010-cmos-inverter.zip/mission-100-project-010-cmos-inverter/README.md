# Project 010 — CMOS Inverter Design and Analysis

**Mission 100 Verilog Projects · Semiconductor Fundamentals → CMOS · Project 010/100**

## 1. Objective
Build a complementary MOS (CMOS) inverter using one PMOS and one NMOS transistor. Explore its logic behavior and voltage transfer behavior with SPICE, then verify a simplified RTL abstraction using a Verilog testbench.

## 2. Theory: What is a CMOS inverter?
A CMOS inverter is a fundamental digital circuit that produces the logical complement of its input. It uses a **PMOS pull-up network** connected to the positive supply and an **NMOS pull-down network** connected to ground. Their gates are connected together as the input, and their drains are joined to form the output.

- Input LOW: PMOS turns ON and NMOS turns OFF; output is pulled toward `VDD` (logic HIGH).
- Input HIGH: NMOS turns ON and PMOS turns OFF; output is pulled toward ground (logic LOW).
- During a real transition, both devices can briefly conduct, producing transient current. The exact transition depends on device models, sizing, load capacitance, and supply voltage.

### Why CMOS is widely used
In stable logic states, ideally one transistor is OFF, so the direct DC path from supply to ground is very small apart from leakage. CMOS offers low static power, good noise margins, and high integration density, making it a foundation of modern digital ICs.

## 3. Circuit structure
- `VDD = 5 V` for this educational circuit.
- PMOS source and bulk connect to `VDD`.
- NMOS source and bulk connect to ground.
- Both gates share `VIN`.
- Both drains join at `VOUT`.
- A small load capacitor is connected from `VOUT` to ground to show switching transients.

**Important:** This is a generic Level-1 educational model, not a process-calibrated CMOS design or a model of a particular commercial IC.

## 4. Key equations and concepts
- Inversion: `VOUT ≈ VDD` for input LOW; `VOUT ≈ 0 V` for input HIGH.
- Static CMOS power: `Pstatic ≈ VDD × Ileakage` in a stable state.
- Dynamic switching power is often approximated as `Pdynamic = α Cload VDD² f`, where `α` is switching activity, `Cload` is effective load capacitance, and `f` is clock/switching frequency.
- The voltage transfer characteristic (VTC) plots `VOUT` against `VIN`. Its transition region and switching threshold depend on transistor parameters and sizing.

## 5. What the simulations do
- **SPICE DC sweep:** sweeps `VIN` from 0 V to 5 V and records the output transfer characteristic.
- **SPICE transient:** applies a pulse to the input and records `VIN`, `VOUT`, and supply current.
- **Verilog:** models only the logical inversion and tests both input states. It does not simulate transistor current, delay, analog transition shape, or power.

## 6. Files
- `spice/cmos_inverter_vtc.cir` — DC voltage-transfer sweep.
- `spice/cmos_inverter_transient.cir` — transient switching analysis.
- `verilog/cmos_inverter.v` — synthesizable RTL inverter.
- `tb/tb_cmos_inverter.v` — self-checking testbench.
- `docs/design-notes.md` — design notes and observations.
- `simulation/results-template.md` — enter actual simulator results.
- `.gitignore` — generated output exclusions.

## 7. Run SPICE
Requires ngspice. From the project directory:
```sh
ngspice -b spice/cmos_inverter_vtc.cir
ngspice -b spice/cmos_inverter_transient.cir
```
Review the simulator log and generated CSV files. Exact model behavior can vary with SPICE version and model implementation.

## 8. Run Verilog
Requires Icarus Verilog:
```sh
iverilog -g2012 -s tb_cmos_inverter -o cmos_inv_sim verilog/cmos_inverter.v tb/tb_cmos_inverter.v
vvp cmos_inv_sim
```

## 9. Expected logical behavior
| `VIN` | `VOUT` |
|---:|---:|
| 0 | 1 |
| 1 | 0 |

The table describes logic levels, not the analog voltages produced by SPICE.

## 10. GitHub destination
`mission-100-verilog-projects/01-semiconductor-fundamentals/project-010-cmos-inverter/`

## Status
**Pending verification.** The source files and commands are packaged, but no simulation results are claimed until you run the tools and inspect the output.
