# Simulation Results — Project 010

**Date:**  
**ngspice version:**  
**Icarus Verilog version:**  

## SPICE DC sweep
- Command executed:
- Netlist ran without errors?
- Output voltage near VIN = 0 V:
- Output voltage near VIN = 2.5 V:
- Output voltage near VIN = 5 V:
- CSV generated:
- Notes on VTC / model behavior:

## SPICE transient
- Command executed:
- Input and output transition observed?
- Peak/qualitative supply-current observation:
- CSV generated:
- Notes:

## Verilog testbench
- Command executed:
- PASS checks:
- FAIL checks:
- Final result line:

## Conclusion
Summarize the actual observations. Do not report expected behavior as measured results.
