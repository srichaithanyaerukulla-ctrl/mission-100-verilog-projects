`timescale 1ns/1ps
module tb_cmos_inverter;
    reg a;
    wire y;
    integer errors;

    cmos_inverter dut (.a(a), .y(y));

    initial begin
        errors = 0;
        $display("Project 010: CMOS inverter RTL checks");
        a = 1'b0; #10;
        if (y !== 1'b1) begin $display("FAIL: input 0 should produce output 1"); errors = errors + 1; end
        else $display("PASS: input 0 -> output 1");
        a = 1'b1; #10;
        if (y !== 1'b0) begin $display("FAIL: input 1 should produce output 0"); errors = errors + 1; end
        else $display("PASS: input 1 -> output 0");
        if (errors == 0) $display("RESULT: ALL RTL CHECKS PASSED");
        else $display("RESULT: %0d CHECK(S) FAILED", errors);
        $finish;
    end
endmodule
