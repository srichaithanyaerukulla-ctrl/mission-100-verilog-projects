# Design Notes — CMOS Inverter

## Topology
The PMOS is the pull-up device: source and bulk at `VDD`. The NMOS is the pull-down device: source and bulk at ground. Gates share the input; drains share the output.

## Operating states
- `VIN = 0 V`: PMOS is on, NMOS is off, so `VOUT` is pulled high.
- `VIN = VDD`: NMOS is on, PMOS is off, so `VOUT` is pulled low.
- Intermediate input voltages may cause both devices to conduct. This is the transition region of the VTC and may create short-circuit current.

## Power
Ideal static CMOS has negligible direct supply-to-ground current in stable states, apart from leakage. Dynamic power rises with load capacitance, supply voltage, switching activity, and frequency. A common approximation is `Pdynamic = α Cload VDD² f`; conventions for the activity factor `α` vary.

## Model limitations
The Level-1 MOSFET models are generic and educational. They do not represent a real fabrication process. The Verilog module only implements `y = ~a`, so it cannot reproduce analog VTC shape, delay, current, or power.
