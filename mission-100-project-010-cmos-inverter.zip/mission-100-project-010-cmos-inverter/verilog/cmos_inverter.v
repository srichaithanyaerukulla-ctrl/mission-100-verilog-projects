// Project 010: synthesizable RTL CMOS inverter abstraction.
// This represents Boolean behavior, not transistor-level analog effects.
module cmos_inverter (
    input  wire a,
    output wire y
);
    assign y = ~a;
endmodule
