# Design Notes — Project 013

An AND function can be built by cascading a NAND and an inverter: nbar = ~(A & B), then Y = ~nbar = A & B. The extra inverter restores polarity but adds capacitance, area, and propagation delay in a physical implementation. This project practices composing cells rather than treating each Boolean operator as an isolated gate. The SPICE netlist contains a transistor-level NAND stage followed by a CMOS inverter.

## Validation
- Run the included testbench.
- Review warnings and confirm expected state/logic transitions.
- For SPICE projects, inspect waveform and model assumptions.
