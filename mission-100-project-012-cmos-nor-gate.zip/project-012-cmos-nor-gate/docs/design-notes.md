# Design Notes — Project 012

A CMOS NOR implements Y = ~(A | B). Two PMOS devices are in series, so the output rises HIGH only when both inputs are LOW. Two NMOS devices are in parallel, so either HIGH input can pull the output LOW. Series PMOS devices affect pull-up resistance and sizing. NOR is a universal CMOS logic primitive; the SPICE models in this project are generic and educational.

## Validation
- Run the included testbench.
- Review warnings and confirm expected state/logic transitions.
- For SPICE projects, inspect waveform and model assumptions.
