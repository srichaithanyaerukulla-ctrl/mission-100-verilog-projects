`timescale 1ns/1ps
module tb_cmos_nor; reg a,b; wire y; integer e;
cmos_nor dut(a,b,y);
initial begin e=0;
{a,b}=0; #10; if(y!==1) e=e+1;
{a,b}=1; #10; if(y!==0) e=e+1;
{a,b}=2; #10; if(y!==0) e=e+1;
{a,b}=3; #10; if(y!==0) e=e+1;
if(e==0) $display("PASS: NOR truth table"); else $display("FAIL %0d",e); $finish; end endmodule