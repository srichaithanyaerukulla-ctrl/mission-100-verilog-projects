# Project 012 — CMOS NOR Gate Design and Analysis

**Mission 100 Verilog Projects · Semiconductor-to-VLSI Journey · Project 012/100**

## Objective
CMOS NOR Gate Design and Analysis: implement the design and verify its behavior with a self-checking Verilog testbench.

## Theory
A CMOS NOR implements Y = ~(A | B). Two PMOS devices are in series, so the output rises HIGH only when both inputs are LOW. Two NMOS devices are in parallel, so either HIGH input can pull the output LOW. Series PMOS devices affect pull-up resistance and sizing. NOR is a universal CMOS logic primitive; the SPICE models in this project are generic and educational.

## Design approach
The RTL models functional logic or storage. It does not automatically reproduce analog transistor behavior, power, propagation delay, or metastability. Where a SPICE netlist is provided, it uses generic educational MOSFET models rather than a foundry-calibrated process model.

## Files
- `README.md` — theory and run instructions.
- `verilog/cmos_nor_gate.v` — Verilog implementation.
- `tb/tb_cmos_nor_gate.v` — self-checking testbench.
- `spice/cmos_nor_gate.cir` — illustrative transistor-level SPICE circuit.\n- `docs/design-notes.md` — design considerations.
- `simulation/results-template.md` — record actual results.

## Run Verilog
```sh
iverilog -g2012 -s tb_cmos_nor_gate -o sim_out verilog/cmos_nor_gate.v tb/tb_cmos_nor_gate.v
vvp sim_out
```

## Run SPICE
```sh
ngspice -b spice/cmos_nor_gate.cir
```
Inspect the log and generated CSV. Simulator syntax and model behavior can vary by version.

## Verification status
**Pending verification.** The files are packaged for execution, but no test or SPICE result is claimed until you run the simulator and inspect its output.
