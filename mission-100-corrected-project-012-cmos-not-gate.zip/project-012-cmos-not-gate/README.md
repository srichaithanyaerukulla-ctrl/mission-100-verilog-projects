# Project 012 — CMOS NOT Gate

**Mission 100 Verilog Projects · CMOS Logic Design · Project 012/100**

## Objective
Study **Inverter design** by understanding the transistor-level circuit, writing a functional Verilog model, and checking its truth table with a self-checking testbench.

## Theory
A CMOS NOT gate (inverter) produces the complement of its input: `Y = ~A`. The PMOS is the pull-up device, with source and bulk tied to VDD. The NMOS is the pull-down device, with source and bulk tied to ground. Their gates share the input and their drains share the output.

When A is LOW, the PMOS is ON and the NMOS is OFF, pulling Y toward VDD. When A is HIGH, the NMOS is ON and the PMOS is OFF, pulling Y toward ground. During transitions, both devices may briefly conduct. The voltage transfer characteristic depends on transistor sizing, model parameters, supply voltage, and load capacitance.

## Expected behavior
Output is HIGH for LOW input and LOW for HIGH input.

## Files
- `README.md` — theory and run guide.
- `verilog/cmos_not_gate.v` — Verilog implementation.
- `tb/tb_cmos_not_gate.v` — self-checking testbench.
- `spice/cmos_not_gate.cir` — illustrative transistor-level SPICE netlist.
- `docs/design-notes.md` — design considerations and limitations.
- `simulation/results-template.md` — record actual results.
- `.gitignore` — ignores generated outputs.

## Run Verilog
Run from this project folder:
```sh
iverilog -g2012 -s tb_cmos_not_gate -o sim_out verilog/cmos_not_gate.v tb/tb_cmos_not_gate.v
vvp sim_out
```

## Run SPICE
Requires ngspice:
```sh
ngspice -b spice/cmos_not_gate.cir
```
Inspect the simulator output and CSV file. SPICE syntax and model behavior may vary by simulator version.

## Model and verification limits
The SPICE examples use generic Level-1 MOSFET models with illustrative parameters; they are not vendor- or foundry-calibrated. The RTL modules represent Boolean functionality and do not calculate transistor current, analog delay, leakage, or physical power. Run the actual commands and inspect outputs before marking a project verified.

## GitHub destination
`mission-100-verilog-projects/02-cmos-logic/project-012-cmos-not-gate/`

## Verification status
**Pending verification.** These source files are prepared for execution, but the simulations have not been reported as run or passed.
