# Design Notes — Project 012: CMOS NOT Gate

## Design theory
A CMOS NOT gate (inverter) produces the complement of its input: `Y = ~A`. The PMOS is the pull-up device, with source and bulk tied to VDD. The NMOS is the pull-down device, with source and bulk tied to ground. Their gates share the input and their drains share the output.

When A is LOW, the PMOS is ON and the NMOS is OFF, pulling Y toward VDD. When A is HIGH, the NMOS is ON and the PMOS is OFF, pulling Y toward ground. During transitions, both devices may briefly conduct. The voltage transfer characteristic depends on transistor sizing, model parameters, supply voltage, and load capacitance.

## Expected behavior
Output is HIGH for LOW input and LOW for HIGH input.

## Implementation cautions
## Model and verification limits
The SPICE examples use generic Level-1 MOSFET models with illustrative parameters; they are not vendor- or foundry-calibrated. The RTL modules represent Boolean functionality and do not calculate transistor current, analog delay, leakage, or physical power. Run the actual commands and inspect outputs before marking a project verified.
