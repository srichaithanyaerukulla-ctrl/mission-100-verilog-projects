// Simplified digital abstraction of a P-channel enhancement MOSFET.
// This is NOT a transistor-level or analog MOSFET model.
`timescale 1ns/1ps
module pmos_enhancement_model #(
    parameter real VTH = 2.0
) (
    input real vgs,
    output reg drain_on
);
    // For this abstraction, VGS is measured as gate voltage minus source voltage.
    // A PMOS turns on when VGS is sufficiently negative; it turns off near/above 0 V.
    always @(*) begin
        if (vgs <= -VTH) drain_on = 1'b1;
        else drain_on = 1'b0;
    end
endmodule
