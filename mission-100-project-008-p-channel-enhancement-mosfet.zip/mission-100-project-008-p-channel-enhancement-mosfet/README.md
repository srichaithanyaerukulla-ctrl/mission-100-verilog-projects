# Project 008 — P-Channel Enhancement MOSFET Fundamentals

**Mission 100 Verilog Projects | Semiconductor Fundamentals**

## Objective
Study a P-channel enhancement MOSFET using an educational SPICE DC sweep and a simplified Verilog switching abstraction.

## Learning outcomes
- Identify gate, drain, and source terminals.
- Understand threshold-controlled channel formation in a P-channel enhancement MOSFET.
- Observe how gate voltage relative to the source affects conduction.
- Compare P-channel and N-channel enhancement MOSFET behavior.
- Practice SPICE simulation and Verilog testbench structure.

## Circuit and model
The source is held at +5 V, the drain is connected to ground through a 1 kΩ resistor, and the gate is swept from +5 V down to +2 V. This makes `VGS = VG - VS` move from 0 V toward −3 V, increasing channel conduction in this illustrative P-channel model. The generic model parameters are educational, not a commercial device specification.

## Files
- `spice/pmos_enhancement_sweep.cir` — SPICE DC sweep.
- `verilog/pmos_enhancement_model.v` — simplified digital abstraction.
- `tb/tb_pmos_enhancement_model.v` — self-checking testbench.
- `docs/design-notes.md` — theory, conventions, and limitations.
- `simulation/results-template.md` — record actual results.
- `.gitignore` — excludes generated simulator output.

## Run SPICE
From the project directory:
```bash
ngspice -b spice/pmos_enhancement_sweep.cir
```
The netlist attempts to write `pmos_transfer.csv`. Inspect the simulator output and data for your installed ngspice version.

## Run Verilog
Requires Icarus Verilog:
```bash
iverilog -g2005 -o pmos_sim verilog/pmos_enhancement_model.v tb/tb_pmos_enhancement_model.v
vvp pmos_sim
```

## Expected conceptual behavior
- `VGS` near 0 V: ON in this simple abstraction.
- `VGS` sufficiently negative: the channel conducts; the abstraction switches ON when the magnitude of negative `VGS` reaches its threshold setting.
- The Verilog testbench checks only the digital abstraction, not analog current or SPICE model accuracy.

## Repository destination
`mission-100-verilog-projects/01-semiconductor-fundamentals/project-008-p-channel-enhancement-mosfet/`

## Status
Simulation status: **Pending local run**. Do not mark verified until both simulations have been run and outputs reviewed.
