# Simulation Results — Project 008

**Date:**  
**ngspice version:**  
**Icarus Verilog version:**  

## SPICE DC sweep
- Command executed:
- Did the netlist run without errors?
- Drain voltage near gate = +5 V:
- Drain voltage near gate = +3.5 V:
- Drain voltage near gate = +2 V:
- CSV generated:
- Notes / model-sign convention issues:

## Verilog testbench
- Command executed:
- PASS checks:
- FAIL checks:
- Final result line:
- Notes:

## Conclusion
Summarize the actual outputs. Do not report expected behavior as measured data.
