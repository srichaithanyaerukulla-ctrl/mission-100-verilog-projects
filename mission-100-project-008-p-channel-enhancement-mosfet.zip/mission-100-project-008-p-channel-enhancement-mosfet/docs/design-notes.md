# Design Notes — P-Channel Enhancement MOSFET

## Important voltage convention
`VGS = VG - VS` (gate voltage minus source voltage). For a typical enhancement PMOS, conduction increases when `VGS` becomes sufficiently negative relative to its source. The source is often at the higher supply potential in a high-side switching arrangement.

## Terminal roles
- **Gate (G):** controls channel formation.
- **Drain (D):** connected to the load side in this example.
- **Source (S):** held at +5 V.
- **Bulk (B):** tied to the source in the example.

## SPICE sweep
The netlist sets the source to +5 V and sweeps the gate from +5 V down to +2 V, which makes `VGS` go from 0 V to −3 V. This moves the device toward ON for the usual enhancement-PMOS polarity. The model's sign conventions can vary with simulator/model syntax; inspect the actual curve and adjust model parameters if needed. The Level-1 parameters are illustrative only.

## Verilog abstraction limitation
The behavioral module accepts `vgs` as a real-valued input and declares the simplified switch ON only when `VGS <= -VTH`. This represents a PMOS controlled by a sufficiently negative gate-to-source voltage. It does not model analog current, body diode, capacitance, temperature, leakage, switching delay, or load-line behavior.

## Suggested observations
1. Compare the threshold abstraction with the SPICE curve qualitatively.
2. Note that PMOS and NMOS turn-on polarities are opposite when `VGS` is defined consistently.
3. Do not treat the simplified Verilog result as a validated semiconductor simulation.
