# Design Notes — NPN BJT Switch

## Terminals
- Base (B): controls conduction.
- Collector (C): connected to the load resistor and +5 V.
- Emitter (E): connected to ground in this low-side switch.

## OFF state
At VIN = 0 V, the base-emitter junction is not forward biased, base current is approximately zero, and Q1 is OFF. RC pulls the collector toward +5 V.

## ON state
At VIN = 5 V, current flows through RB into the base. The transistor conducts and pulls the collector toward ground. With enough base drive, it enters saturation.

## First-order estimates
Assuming VBE ≈ 0.7 V:
IB ≈ (5 V - 0.7 V) / 10 kΩ ≈ 0.43 mA.

Assuming VCE(sat) ≈ 0.2 V:
IC ≈ (5 V - 0.2 V) / 1 kΩ ≈ 4.8 mA.

These are rough estimates. Actual behavior depends on the selected transistor model, temperature, and device parameters. Confirm using SPICE and the transistor datasheet.

## Why SPICE?
SPICE models electrical quantities such as node voltages, branch currents, operating points, and switching transients. Digital Verilog simulation does not provide these analog details.

## Verilog model limitation
The Verilog module is only a functional abstraction: drive LOW means OFF and drive HIGH means ON. It is not a BJT primitive and does not simulate transistor physics.
