# Project 002 — NPN BJT as a Switch

**Mission 100: Semiconductor-to-VLSI Journey**  
**Status:** Prepared; run simulations before marking verified.

## Objective
Study an NPN bipolar junction transistor (BJT) as a low-side switch using SPICE, then compare its behavior with a simple Verilog digital abstraction.

## Circuit
- Q1: NPN transistor using an educational 2N2222-style model
- Supply: 5 V
- Collector resistor: 1 kΩ
- Base resistor: 10 kΩ
- Input: 0-to-5 V pulse
- Emitter: ground

Input LOW: transistor OFF; collector is pulled toward +5 V through the collector resistor.  
Input HIGH: base current flows; transistor conducts and pulls the collector toward ground if the base drive is sufficient.

## Files
- `spice/npn_bjt_switch.cir`: ngspice transient netlist
- `verilog/npn_bjt_switch_model.v`: digital functional abstraction, not a physical BJT model
- `tb/tb_npn_bjt_switch.v`: testbench
- `docs/design-notes.md`: concepts and calculations
- `simulation/results-template.md`: record actual simulation results

## Run SPICE
From this folder, with ngspice installed:
```bash
ngspice -b spice/npn_bjt_switch.cir
```
The netlist attempts to write `bjt_switch.csv` in the current working directory. If needed, run `ngspice spice/npn_bjt_switch.cir` interactively and plot `v(in)` and `v(col)`.

## Run the Verilog abstraction
With Icarus Verilog installed:
```bash
iverilog -g2005 -o bjt_model_sim verilog/npn_bjt_switch_model.v tb/tb_npn_bjt_switch.v
vvp bjt_model_sim
```

Expected digital behavior:
- drive=0 -> transistor_on=0, collector_logic=1
- drive=1 -> transistor_on=1, collector_logic=0

The Verilog abstraction does not model base current, transistor gain, saturation voltage, analog waveforms, or switching delay. Use SPICE for those electrical effects.

## Completion checklist
- [ ] Identify base, collector, and emitter
- [ ] Run SPICE and inspect input/collector voltages
- [ ] Run the Verilog testbench
- [ ] Save actual simulator logs/screenshots
- [ ] Explain OFF and ON states in your own words
- [ ] Update `simulation/results-template.md`

## Safety
For physical construction, confirm the selected transistor's pinout from its datasheet and use current-limiting resistors. Never connect this low-voltage learning circuit directly to mains voltage.
