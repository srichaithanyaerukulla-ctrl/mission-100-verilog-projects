# Simulation Results — Project 002

**Status: Not yet verified. Complete after running the simulators.**

## SPICE
- Simulator/version:
- Command:
- Simulation completed?:
- Approximate collector voltage with input LOW:
- Approximate collector voltage with input HIGH:
- Observed transition behavior:
- Screenshot/log filename:

## Verilog digital abstraction
- Simulator/version:
- Command:
- Testbench result:
- Screenshot/log filename:

## Interpretation
Explain why the collector is high when the transistor is OFF and low when it is ON.

## Limitations
The Verilog model is digital-only. It does not model analog current, voltage, gain, saturation, or switching delay.
