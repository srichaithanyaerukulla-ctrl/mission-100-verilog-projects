// Functional digital abstraction of an NPN low-side switch.
// NOT a transistor-level BJT electrical model.
module npn_bjt_switch_model (
    input  wire drive,
    output wire transistor_on,
    output wire collector_logic
);
    assign transistor_on = drive;
    assign collector_logic = ~drive;
endmodule
