# Project 016 — 2-to-1 Multiplexer Design

**Mission 100 Verilog Projects · Semiconductor-to-VLSI Journey · Project 016/100**

## Objective
2-to-1 Multiplexer Design: implement the design and verify its behavior with a self-checking Verilog testbench.

## Theory
A 2:1 multiplexer selects D0 or D1 using select S. Its Boolean equation is Y = (~S & D0) | (S & D1). When S=0, Y follows D0; when S=1, Y follows D1. A gate-level mux uses inverter/AND/OR logic, while a transmission-gate mux uses complementary pass-gate branches. Physical delay depends on select generation, on-resistance, load capacitance, and timing. RTL checks functional selection only.

## Design approach
The RTL models functional logic or storage. It does not automatically reproduce analog transistor behavior, power, propagation delay, or metastability. Where a SPICE netlist is provided, it uses generic educational MOSFET models rather than a foundry-calibrated process model.

## Files
- `README.md` — theory and run instructions.
- `verilog/two_to_one_multiplexer.v` — Verilog implementation.
- `tb/tb_two_to_one_multiplexer.v` — self-checking testbench.
- `spice/two_to_one_multiplexer.cir` — illustrative transistor-level SPICE circuit.\n- `docs/design-notes.md` — design considerations.
- `simulation/results-template.md` — record actual results.

## Run Verilog
```sh
iverilog -g2012 -s tb_two_to_one_multiplexer -o sim_out verilog/two_to_one_multiplexer.v tb/tb_two_to_one_multiplexer.v
vvp sim_out
```

## Run SPICE
```sh
ngspice -b spice/two_to_one_multiplexer.cir
```
Inspect the log and generated CSV. Simulator syntax and model behavior can vary by version.

## Verification status
**Pending verification.** The files are packaged for execution, but no test or SPICE result is claimed until you run the simulator and inspect its output.
