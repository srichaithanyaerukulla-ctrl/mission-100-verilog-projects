`timescale 1ns/1ps
module tb_mux2to1; reg d0,d1,s; wire y; integer e;
mux2to1 dut(d0,d1,s,y);
initial begin e=0;
d0=0;d1=1;s=0;#10;if(y!==0)e=e+1;
d0=0;d1=1;s=1;#10;if(y!==1)e=e+1;
d0=1;d1=0;s=0;#10;if(y!==1)e=e+1;
d0=1;d1=0;s=1;#10;if(y!==0)e=e+1;
if(e==0)$display("PASS: 2:1 mux");else $display("FAIL %0d",e);$finish;end endmodule