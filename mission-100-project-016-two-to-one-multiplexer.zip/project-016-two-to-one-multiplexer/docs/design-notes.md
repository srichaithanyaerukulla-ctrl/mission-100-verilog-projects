# Design Notes — Project 016

A 2:1 multiplexer selects D0 or D1 using select S. Its Boolean equation is Y = (~S & D0) | (S & D1). When S=0, Y follows D0; when S=1, Y follows D1. A gate-level mux uses inverter/AND/OR logic, while a transmission-gate mux uses complementary pass-gate branches. Physical delay depends on select generation, on-resistance, load capacitance, and timing. RTL checks functional selection only.

## Validation
- Run the included testbench.
- Review warnings and confirm expected state/logic transitions.
- For SPICE projects, inspect waveform and model assumptions.
