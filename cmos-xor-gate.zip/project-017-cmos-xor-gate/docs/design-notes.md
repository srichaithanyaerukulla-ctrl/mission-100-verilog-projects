# Design Notes — Project 017: CMOS XOR Gate

## Design theory
XOR produces HIGH when the inputs differ: `Y = A ⊕ B = (~A & B) | (A & ~B)`. For two inputs, its output is LOW when the inputs are equal. XOR is commonly used in parity generation, adders, and comparison logic.

A transistor-level XOR can be implemented with a carefully designed complementary network or composed from NAND gates. This package uses a NAND-based structural SPICE implementation to make the network easier to inspect. In a practical standard-cell library, XOR cells are often larger than NAND/NOR cells because the function needs more devices and internal nodes.

## Expected behavior
Output is HIGH for 01 and 10; LOW for 00 and 11.

## Implementation cautions
## Model and verification limits
The SPICE examples use generic Level-1 MOSFET models with illustrative parameters; they are not vendor- or foundry-calibrated. The RTL modules represent Boolean functionality and do not calculate transistor current, analog delay, leakage, or physical power. Run the actual commands and inspect outputs before marking a project verified.
