`timescale 1ns/1ps
module tb_cmos_xor_gate;
reg a,b; wire y; integer errors;
cmos_xor_gate dut(.a(a),.b(b),.y(y));
task check(input reg aa, input reg bb, input reg expected);
begin a=aa; b=bb; #10; if(y!==expected) errors=errors+1; end endtask
initial begin errors=0; check(0,0,0); check(0,1,1); check(1,0,1); check(1,1,0);
if(errors==0) $display("PASS: CMOS XOR truth table"); else $display("FAIL: %0d errors",errors); $finish; end
endmodule
