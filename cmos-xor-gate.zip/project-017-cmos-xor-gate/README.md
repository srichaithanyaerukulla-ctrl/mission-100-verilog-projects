# Project 017 — CMOS XOR Gate

**Mission 100 Verilog Projects · CMOS Logic Design · Project 017/100**

## Objective
Study **Complex transistor networks** by understanding the transistor-level circuit, writing a functional Verilog model, and checking its truth table with a self-checking testbench.

## Theory
XOR produces HIGH when the inputs differ: `Y = A ⊕ B = (~A & B) | (A & ~B)`. For two inputs, its output is LOW when the inputs are equal. XOR is commonly used in parity generation, adders, and comparison logic.

A transistor-level XOR can be implemented with a carefully designed complementary network or composed from NAND gates. This package uses a NAND-based structural SPICE implementation to make the network easier to inspect. In a practical standard-cell library, XOR cells are often larger than NAND/NOR cells because the function needs more devices and internal nodes.

## Expected behavior
Output is HIGH for 01 and 10; LOW for 00 and 11.

## Files
- `README.md` — theory and run guide.
- `verilog/cmos_xor_gate.v` — Verilog implementation.
- `tb/tb_cmos_xor_gate.v` — self-checking testbench.
- `spice/cmos_xor_gate.cir` — illustrative transistor-level SPICE netlist.
- `docs/design-notes.md` — design considerations and limitations.
- `simulation/results-template.md` — record actual results.
- `.gitignore` — ignores generated outputs.

## Run Verilog
Run from this project folder:
```sh
iverilog -g2012 -s tb_cmos_xor_gate -o sim_out verilog/cmos_xor_gate.v tb/tb_cmos_xor_gate.v
vvp sim_out
```

## Run SPICE
Requires ngspice:
```sh
ngspice -b spice/cmos_xor_gate.cir
```
Inspect the simulator output and CSV file. SPICE syntax and model behavior may vary by simulator version.

## Model and verification limits
The SPICE examples use generic Level-1 MOSFET models with illustrative parameters; they are not vendor- or foundry-calibrated. The RTL modules represent Boolean functionality and do not calculate transistor current, analog delay, leakage, or physical power. Run the actual commands and inspect outputs before marking a project verified.

## GitHub destination
`mission-100-verilog-projects/02-cmos-logic/project-017-cmos-xor-gate/`

## Verification status
**Pending verification.** These source files are prepared for execution, but the simulations have not been reported as run or passed.
