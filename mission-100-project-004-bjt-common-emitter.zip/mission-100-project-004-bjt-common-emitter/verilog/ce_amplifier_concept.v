// Conceptual inversion only. NOT an analog amplifier model.
// Do not use this module to predict gain or voltage waveforms.
module ce_amplifier_concept (
    input  wire input_high,
    output wire output_low
);
    assign output_low = ~input_high;
endmodule
