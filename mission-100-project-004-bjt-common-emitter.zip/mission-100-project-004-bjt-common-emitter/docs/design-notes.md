# Design Notes — Common-Emitter BJT Amplifier

## Configuration
The emitter is the common reference for input and output signals. Input enters the base through a coupling capacitor; output is taken from the collector through an output coupling capacitor.

## DC bias
R1 and R2 establish base bias. RE adds negative feedback and helps stabilize the operating point. RC converts collector-current changes into collector-voltage changes.

## Inverting action
When the input nudges base-emitter voltage upward, collector current generally increases. The voltage drop across RC rises, so collector voltage falls. The small-signal collector output is therefore approximately 180 degrees out of phase with the input while the transistor remains in its active region.

## Capacitors
CIN and COUT block DC while passing AC. CE bypasses RE for AC signals over a frequency-dependent range, increasing AC gain while retaining DC emitter degeneration.

## What to inspect
- Check the DC operating point first.
- Plot input and output waveforms.
- Compare amplitude and phase.
- If the output clips or bias is poor, adjust the bias network or input amplitude.

## Verilog limitation
The included Verilog is only a binary conceptual illustration of inversion. It does not model analog voltage gain, biasing, frequency response, distortion, noise, or transistor physics.
