# Project 004 — BJT Common-Emitter Amplifier

Mission 100: Semiconductor-to-VLSI Journey  
Project 004 / 100 | Status: Prepared; simulation verification pending.

## Objective
Simulate an NPN common-emitter amplifier using SPICE. Observe how a small AC input around a DC bias point produces an amplified, inverted output. A Verilog file is included only as a conceptual illustration; it is not an analog amplifier model.

## Circuit
- Supply: 12 V
- NPN model: educational Q2N3904-style model
- Collector resistor: 4.7 kΩ
- Emitter resistor: 1 kΩ
- Base divider: 47 kΩ from +12 V to base, 10 kΩ from base to ground
- Input coupling capacitor: 10 µF
- Output coupling capacitor: 10 µF
- Emitter bypass capacitor: 100 µF
- Load: 10 kΩ
- Input: 10 mV peak sine wave at 1 kHz

## Files
- `spice/bjt_common_emitter.cir`: ngspice netlist
- `verilog/ce_amplifier_concept.v`: conceptual inversion only
- `tb/tb_ce_amplifier_concept.v`: testbench for conceptual model
- `docs/design-notes.md`: operating principles
- `simulation/results-template.md`: fill in after running simulations

## Run SPICE
```bash
ngspice -b spice/bjt_common_emitter.cir
```
The netlist attempts to write `ce_amplifier.csv` in the working directory. For interactive inspection, run `ngspice spice/bjt_common_emitter.cir` and plot `v(src)` and `v(out)`.

## Run the Verilog concept test
```bash
iverilog -g2005 -o ce_concept_sim verilog/ce_amplifier_concept.v tb/tb_ce_amplifier_concept.v
vvp ce_concept_sim
```

**Important:** The Verilog module does not model gain, voltage/current, biasing, frequency response, distortion, noise, or transistor physics. Use SPICE for real circuit analysis.

## Completion checklist
- [ ] Run SPICE simulation
- [ ] Check DC operating point
- [ ] Observe input/output amplitude and phase
- [ ] Run the Verilog conceptual testbench
- [ ] Save actual logs/screenshots
- [ ] Fill in `simulation/results-template.md`

Safety: confirm component ratings and transistor pinout before physical construction. Never connect directly to mains voltage.
