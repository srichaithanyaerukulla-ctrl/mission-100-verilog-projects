# Simulation Results — Project 004

**Status: Not yet verified. Fill this after running the simulators.**

## SPICE
- Simulator/version:
- Command:
- Simulation completed?:
- DC base voltage:
- DC emitter voltage:
- DC collector voltage:
- Input amplitude observed:
- Output amplitude observed:
- Approximate voltage gain:
- Is output inverted?:
- Screenshot/log filename:

## Verilog concept model
- Simulator/version:
- Command:
- Testbench result:
- Screenshot/log filename:

## Interpretation
Explain why increasing collector current makes collector voltage fall in a common-emitter amplifier.

## Limitations
The Verilog module is conceptual only, not a physical amplifier model.
