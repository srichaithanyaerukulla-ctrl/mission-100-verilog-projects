# Design Notes — Project 014

An OR function can be built by cascading a NOR and an inverter: nbar = ~(A | B), then Y = ~nbar = A | B. This demonstrates polarity restoration and cell composition. The extra inverter adds load and propagation delay. The transistor-level circuit uses series PMOS and parallel NMOS devices for the NOR stage, followed by a CMOS inverter.

## Validation
- Run the included testbench.
- Review warnings and confirm expected state/logic transitions.
- For SPICE projects, inspect waveform and model assumptions.
