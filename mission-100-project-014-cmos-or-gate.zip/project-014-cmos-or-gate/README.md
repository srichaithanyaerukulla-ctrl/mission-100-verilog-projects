# Project 014 — CMOS OR Gate Using NOR and Inverter

**Mission 100 Verilog Projects · Semiconductor-to-VLSI Journey · Project 014/100**

## Objective
CMOS OR Gate Using NOR and Inverter: implement the design and verify its behavior with a self-checking Verilog testbench.

## Theory
An OR function can be built by cascading a NOR and an inverter: nbar = ~(A | B), then Y = ~nbar = A | B. This demonstrates polarity restoration and cell composition. The extra inverter adds load and propagation delay. The transistor-level circuit uses series PMOS and parallel NMOS devices for the NOR stage, followed by a CMOS inverter.

## Design approach
The RTL models functional logic or storage. It does not automatically reproduce analog transistor behavior, power, propagation delay, or metastability. Where a SPICE netlist is provided, it uses generic educational MOSFET models rather than a foundry-calibrated process model.

## Files
- `README.md` — theory and run instructions.
- `verilog/cmos_or_gate.v` — Verilog implementation.
- `tb/tb_cmos_or_gate.v` — self-checking testbench.
- `spice/cmos_or_gate.cir` — illustrative transistor-level SPICE circuit.\n- `docs/design-notes.md` — design considerations.
- `simulation/results-template.md` — record actual results.

## Run Verilog
```sh
iverilog -g2012 -s tb_cmos_or_gate -o sim_out verilog/cmos_or_gate.v tb/tb_cmos_or_gate.v
vvp sim_out
```

## Run SPICE
```sh
ngspice -b spice/cmos_or_gate.cir
```
Inspect the log and generated CSV. Simulator syntax and model behavior can vary by version.

## Verification status
**Pending verification.** The files are packaged for execution, but no test or SPICE result is claimed until you run the simulator and inspect its output.
