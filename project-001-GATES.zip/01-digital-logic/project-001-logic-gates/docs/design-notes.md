# Design Notes — Project 001

## Truth table

| a | b | AND | OR | NOT a | NAND | NOR | XOR | XNOR |
|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| 0 | 0 | 0 | 0 | 1 | 1 | 1 | 0 | 1 |
| 0 | 1 | 0 | 1 | 1 | 1 | 0 | 1 | 0 |
| 1 | 0 | 0 | 1 | 0 | 1 | 0 | 1 | 0 |
| 1 | 1 | 1 | 1 | 0 | 0 | 0 | 0 | 1 |

## Modeling-style comparison

- **Switch-level:** Describes transistor-like switches. Useful for learning CMOS pull-up/pull-down networks, but not a replacement for SPICE or transistor-level physical analysis.
- **Gate-level:** Uses built-in primitives such as `and`, `nand`, `xor`, and `not`.
- **Dataflow:** Expresses Boolean relationships with operators and continuous assignments.
- **Behavioral:** Expresses combinational behavior inside `always @(*)`; output variables are declared `reg` in Verilog.

## Expected behavior

For all two-input gates, the testbench checks all four combinations of `a` and `b`. For the inverter, it checks both values of `a` (the four-vector sweep naturally covers both).

## Debugging exercise

Change one implementation from `a & b` to `a | b` for the AND output. The self-checking testbench should detect a mismatch for at least one input combination. Restore the correct expression after confirming the failure.
