// Dataflow modeling: NAND and NOR gates
// Project 001 - Mission 100 Verilog Projects
module universal_gates_dataflow (
    input wire a,
    input wire b,
    output wire y_nand, output wire y_nor
);

    assign y_nand = ~(a & b);
    assign y_nor  = ~(a | b);

endmodule
