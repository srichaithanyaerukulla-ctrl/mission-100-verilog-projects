// Gate-level modeling: NAND and NOR gates
// Project 001 - Mission 100 Verilog Projects
module universal_gates_gate_level (
    input wire a,
    input wire b,
    output wire y_nand, output wire y_nor
);

    nand (y_nand, a, b);
    nor  (y_nor,  a, b);

endmodule
