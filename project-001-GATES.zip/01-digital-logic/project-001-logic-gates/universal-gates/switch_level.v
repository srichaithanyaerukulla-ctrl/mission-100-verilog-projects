// Switch-level modeling: NAND and NOR gates
// Project 001 - Mission 100 Verilog Projects
module universal_gates_switch_level (
    input wire a,
    input wire b,
    output wire y_nand, output wire y_nor
);

    supply1 vdd;
    supply0 gnd;
    wire nand_mid;
    wire nor_mid;

    // CMOS NAND: parallel pMOS pull-up, series nMOS pull-down.
    pmos (y_nand, vdd, a);
    pmos (y_nand, vdd, b);
    nmos (nand_mid, gnd, a);
    nmos (y_nand, nand_mid, b);

    // CMOS NOR: series pMOS pull-up, parallel nMOS pull-down.
    pmos (nor_mid, vdd, a);
    pmos (y_nor, nor_mid, b);
    nmos (y_nor, gnd, a);
    nmos (y_nor, gnd, b);

endmodule
