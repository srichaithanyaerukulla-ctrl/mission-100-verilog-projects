# Universal Gates

Implements NAND and NOR gates in four Verilog modeling styles.

- `switch_level.v`: transistor/switch primitives (`pmos`, `nmos`, and `cmos`).
- `gate_level.v`: built-in gate primitives.
- `dataflow.v`: continuous assignments and Boolean operators.
- `behavioral.v`: combinational `always @(*)` modeling.

Compile all files with the shared testbench from the project root. Switch-level transistor models are educational logic models; detailed analog transistor behavior and physical timing are not modeled.
