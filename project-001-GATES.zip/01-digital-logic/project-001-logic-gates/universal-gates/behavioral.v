// Behavioral modeling: NAND and NOR gates
// Project 001 - Mission 100 Verilog Projects
module universal_gates_behavioral (
    input wire a,
    input wire b,
    output reg y_nand, output reg y_nor
);

    always @(*) begin
        y_nand = ~(a & b);
        y_nor  = ~(a | b);
    end

endmodule
