// Switch-level modeling: XOR and XNOR gates
// Project 001 - Mission 100 Verilog Projects
module special_gates_switch_level (
    input wire a,
    input wire b,
    output wire y_xor, output wire y_xnor
);

    supply1 vdd;
    supply0 gnd;
    wire na, nb;

    // Invert both inputs to create transmission-gate control/data signals.
    pmos (na, vdd, a);
    nmos (na, gnd, a);
    pmos (nb, vdd, b);
    nmos (nb, gnd, b);

    // XOR = a ? ~b : b, built as a transmission-gate mux.
    cmos (y_xor, b,  na, a);
    cmos (y_xor, nb, a,  na);

    // XNOR = a ? b : ~b, built as a transmission-gate mux.
    cmos (y_xnor, nb, na, a);
    cmos (y_xnor, b,  a,  na);

endmodule
