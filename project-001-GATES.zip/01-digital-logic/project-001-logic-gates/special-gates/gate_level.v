// Gate-level modeling: XOR and XNOR gates
// Project 001 - Mission 100 Verilog Projects
module special_gates_gate_level (
    input wire a,
    input wire b,
    output wire y_xor, output wire y_xnor
);

    xor  (y_xor,  a, b);
    xnor (y_xnor, a, b);

endmodule
