// Dataflow modeling: XOR and XNOR gates
// Project 001 - Mission 100 Verilog Projects
module special_gates_dataflow (
    input wire a,
    input wire b,
    output wire y_xor, output wire y_xnor
);

    assign y_xor  = a ^ b;
    assign y_xnor = ~(a ^ b);

endmodule
