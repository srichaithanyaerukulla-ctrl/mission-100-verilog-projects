// Behavioral modeling: XOR and XNOR gates
// Project 001 - Mission 100 Verilog Projects
module special_gates_behavioral (
    input wire a,
    input wire b,
    output reg y_xor, output reg y_xnor
);

    always @(*) begin
        y_xor  = a ^ b;
        y_xnor = ~(a ^ b);
    end

endmodule
