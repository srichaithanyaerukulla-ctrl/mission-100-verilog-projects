// Gate-level modeling: AND, OR, and NOT gates
// Project 001 - Mission 100 Verilog Projects
module basic_gates_gate_level (
    input wire a,
    input wire b,
    output wire y_and, output wire y_or, output wire y_not
);

    and (y_and, a, b);
    or  (y_or,  a, b);
    not (y_not, a);

endmodule
