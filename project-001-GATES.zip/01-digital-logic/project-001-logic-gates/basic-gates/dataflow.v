// Dataflow modeling: AND, OR, and NOT gates
// Project 001 - Mission 100 Verilog Projects
module basic_gates_dataflow (
    input wire a,
    input wire b,
    output wire y_and, output wire y_or, output wire y_not
);

    assign y_and = a & b;
    assign y_or  = a | b;
    assign y_not = ~a;

endmodule
