// Behavioral modeling: AND, OR, and NOT gates
// Project 001 - Mission 100 Verilog Projects
module basic_gates_behavioral (
    input wire a,
    input wire b,
    output reg y_and, output reg y_or, output reg y_not
);

    always @(*) begin
        y_and = a & b;
        y_or  = a | b;
        y_not = ~a;
    end

endmodule
