// Switch-level modeling: AND, OR, and NOT gates
// Project 001 - Mission 100 Verilog Projects
module basic_gates_switch_level (
    input wire a,
    input wire b,
    output wire y_and, output wire y_or, output wire y_not
);

    supply1 vdd;
    supply0 gnd;
    wire nand_ab, nand_mid;
    wire nor_ab, nor_mid;

    // AND = NAND followed by an inverter.
    pmos (nand_ab, vdd, a);
    pmos (nand_ab, vdd, b);
    nmos (nand_mid, gnd, a);
    nmos (nand_ab, nand_mid, b);
    pmos (y_and, vdd, nand_ab);
    nmos (y_and, gnd, nand_ab);

    // OR = NOR followed by an inverter.
    pmos (nor_mid, vdd, a);
    pmos (nor_ab, nor_mid, b);
    nmos (nor_ab, gnd, a);
    nmos (nor_ab, gnd, b);
    pmos (y_or, vdd, nor_ab);
    nmos (y_or, gnd, nor_ab);

    // NOT gate (inverter).
    pmos (y_not, vdd, a);
    nmos (y_not, gnd, a);

endmodule
