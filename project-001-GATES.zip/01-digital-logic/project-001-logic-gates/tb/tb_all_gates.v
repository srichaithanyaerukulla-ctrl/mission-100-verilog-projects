`timescale 1ns/1ps
// Self-checking testbench for all 12 modeling-style/category modules.
module tb_all_gates;
    reg a, b;
    integer errors;

    wire basic_gates_switch_level_y_and;
    wire basic_gates_switch_level_y_or;
    wire basic_gates_switch_level_y_not;
    basic_gates_switch_level u_basic_gates_switch_level (
        .a(a),
        .b(b),
        .y_and(basic_gates_switch_level_y_and),
        .y_or(basic_gates_switch_level_y_or),
        .y_not(basic_gates_switch_level_y_not)
    );
    wire basic_gates_gate_level_y_and;
    wire basic_gates_gate_level_y_or;
    wire basic_gates_gate_level_y_not;
    basic_gates_gate_level u_basic_gates_gate_level (
        .a(a),
        .b(b),
        .y_and(basic_gates_gate_level_y_and),
        .y_or(basic_gates_gate_level_y_or),
        .y_not(basic_gates_gate_level_y_not)
    );
    wire basic_gates_dataflow_y_and;
    wire basic_gates_dataflow_y_or;
    wire basic_gates_dataflow_y_not;
    basic_gates_dataflow u_basic_gates_dataflow (
        .a(a),
        .b(b),
        .y_and(basic_gates_dataflow_y_and),
        .y_or(basic_gates_dataflow_y_or),
        .y_not(basic_gates_dataflow_y_not)
    );
    wire basic_gates_behavioral_y_and;
    wire basic_gates_behavioral_y_or;
    wire basic_gates_behavioral_y_not;
    basic_gates_behavioral u_basic_gates_behavioral (
        .a(a),
        .b(b),
        .y_and(basic_gates_behavioral_y_and),
        .y_or(basic_gates_behavioral_y_or),
        .y_not(basic_gates_behavioral_y_not)
    );
    wire universal_gates_switch_level_y_nand;
    wire universal_gates_switch_level_y_nor;
    universal_gates_switch_level u_universal_gates_switch_level (
        .a(a),
        .b(b),
        .y_nand(universal_gates_switch_level_y_nand),
        .y_nor(universal_gates_switch_level_y_nor)
    );
    wire universal_gates_gate_level_y_nand;
    wire universal_gates_gate_level_y_nor;
    universal_gates_gate_level u_universal_gates_gate_level (
        .a(a),
        .b(b),
        .y_nand(universal_gates_gate_level_y_nand),
        .y_nor(universal_gates_gate_level_y_nor)
    );
    wire universal_gates_dataflow_y_nand;
    wire universal_gates_dataflow_y_nor;
    universal_gates_dataflow u_universal_gates_dataflow (
        .a(a),
        .b(b),
        .y_nand(universal_gates_dataflow_y_nand),
        .y_nor(universal_gates_dataflow_y_nor)
    );
    wire universal_gates_behavioral_y_nand;
    wire universal_gates_behavioral_y_nor;
    universal_gates_behavioral u_universal_gates_behavioral (
        .a(a),
        .b(b),
        .y_nand(universal_gates_behavioral_y_nand),
        .y_nor(universal_gates_behavioral_y_nor)
    );
    wire special_gates_switch_level_y_xor;
    wire special_gates_switch_level_y_xnor;
    special_gates_switch_level u_special_gates_switch_level (
        .a(a),
        .b(b),
        .y_xor(special_gates_switch_level_y_xor),
        .y_xnor(special_gates_switch_level_y_xnor)
    );
    wire special_gates_gate_level_y_xor;
    wire special_gates_gate_level_y_xnor;
    special_gates_gate_level u_special_gates_gate_level (
        .a(a),
        .b(b),
        .y_xor(special_gates_gate_level_y_xor),
        .y_xnor(special_gates_gate_level_y_xnor)
    );
    wire special_gates_dataflow_y_xor;
    wire special_gates_dataflow_y_xnor;
    special_gates_dataflow u_special_gates_dataflow (
        .a(a),
        .b(b),
        .y_xor(special_gates_dataflow_y_xor),
        .y_xnor(special_gates_dataflow_y_xnor)
    );
    wire special_gates_behavioral_y_xor;
    wire special_gates_behavioral_y_xnor;
    special_gates_behavioral u_special_gates_behavioral (
        .a(a),
        .b(b),
        .y_xor(special_gates_behavioral_y_xor),
        .y_xnor(special_gates_behavioral_y_xnor)
    );

    task check_all;
    begin
        if (basic_gates_switch_level_y_and !== (a & b)) begin
            $display("FAIL: basic_gates_switch_level.y_and a=%b b=%b got=%b expected=%b", a, b, basic_gates_switch_level_y_and, (a & b));
            errors = errors + 1;
        end
        if (basic_gates_switch_level_y_or !== (a | b)) begin
            $display("FAIL: basic_gates_switch_level.y_or a=%b b=%b got=%b expected=%b", a, b, basic_gates_switch_level_y_or, (a | b));
            errors = errors + 1;
        end
        if (basic_gates_switch_level_y_not !== (~a)) begin
            $display("FAIL: basic_gates_switch_level.y_not a=%b b=%b got=%b expected=%b", a, b, basic_gates_switch_level_y_not, (~a));
            errors = errors + 1;
        end
        if (basic_gates_gate_level_y_and !== (a & b)) begin
            $display("FAIL: basic_gates_gate_level.y_and a=%b b=%b got=%b expected=%b", a, b, basic_gates_gate_level_y_and, (a & b));
            errors = errors + 1;
        end
        if (basic_gates_gate_level_y_or !== (a | b)) begin
            $display("FAIL: basic_gates_gate_level.y_or a=%b b=%b got=%b expected=%b", a, b, basic_gates_gate_level_y_or, (a | b));
            errors = errors + 1;
        end
        if (basic_gates_gate_level_y_not !== (~a)) begin
            $display("FAIL: basic_gates_gate_level.y_not a=%b b=%b got=%b expected=%b", a, b, basic_gates_gate_level_y_not, (~a));
            errors = errors + 1;
        end
        if (basic_gates_dataflow_y_and !== (a & b)) begin
            $display("FAIL: basic_gates_dataflow.y_and a=%b b=%b got=%b expected=%b", a, b, basic_gates_dataflow_y_and, (a & b));
            errors = errors + 1;
        end
        if (basic_gates_dataflow_y_or !== (a | b)) begin
            $display("FAIL: basic_gates_dataflow.y_or a=%b b=%b got=%b expected=%b", a, b, basic_gates_dataflow_y_or, (a | b));
            errors = errors + 1;
        end
        if (basic_gates_dataflow_y_not !== (~a)) begin
            $display("FAIL: basic_gates_dataflow.y_not a=%b b=%b got=%b expected=%b", a, b, basic_gates_dataflow_y_not, (~a));
            errors = errors + 1;
        end
        if (basic_gates_behavioral_y_and !== (a & b)) begin
            $display("FAIL: basic_gates_behavioral.y_and a=%b b=%b got=%b expected=%b", a, b, basic_gates_behavioral_y_and, (a & b));
            errors = errors + 1;
        end
        if (basic_gates_behavioral_y_or !== (a | b)) begin
            $display("FAIL: basic_gates_behavioral.y_or a=%b b=%b got=%b expected=%b", a, b, basic_gates_behavioral_y_or, (a | b));
            errors = errors + 1;
        end
        if (basic_gates_behavioral_y_not !== (~a)) begin
            $display("FAIL: basic_gates_behavioral.y_not a=%b b=%b got=%b expected=%b", a, b, basic_gates_behavioral_y_not, (~a));
            errors = errors + 1;
        end
        if (universal_gates_switch_level_y_nand !== (~(a & b))) begin
            $display("FAIL: universal_gates_switch_level.y_nand a=%b b=%b got=%b expected=%b", a, b, universal_gates_switch_level_y_nand, (~(a & b)));
            errors = errors + 1;
        end
        if (universal_gates_switch_level_y_nor !== (~(a | b))) begin
            $display("FAIL: universal_gates_switch_level.y_nor a=%b b=%b got=%b expected=%b", a, b, universal_gates_switch_level_y_nor, (~(a | b)));
            errors = errors + 1;
        end
        if (universal_gates_gate_level_y_nand !== (~(a & b))) begin
            $display("FAIL: universal_gates_gate_level.y_nand a=%b b=%b got=%b expected=%b", a, b, universal_gates_gate_level_y_nand, (~(a & b)));
            errors = errors + 1;
        end
        if (universal_gates_gate_level_y_nor !== (~(a | b))) begin
            $display("FAIL: universal_gates_gate_level.y_nor a=%b b=%b got=%b expected=%b", a, b, universal_gates_gate_level_y_nor, (~(a | b)));
            errors = errors + 1;
        end
        if (universal_gates_dataflow_y_nand !== (~(a & b))) begin
            $display("FAIL: universal_gates_dataflow.y_nand a=%b b=%b got=%b expected=%b", a, b, universal_gates_dataflow_y_nand, (~(a & b)));
            errors = errors + 1;
        end
        if (universal_gates_dataflow_y_nor !== (~(a | b))) begin
            $display("FAIL: universal_gates_dataflow.y_nor a=%b b=%b got=%b expected=%b", a, b, universal_gates_dataflow_y_nor, (~(a | b)));
            errors = errors + 1;
        end
        if (universal_gates_behavioral_y_nand !== (~(a & b))) begin
            $display("FAIL: universal_gates_behavioral.y_nand a=%b b=%b got=%b expected=%b", a, b, universal_gates_behavioral_y_nand, (~(a & b)));
            errors = errors + 1;
        end
        if (universal_gates_behavioral_y_nor !== (~(a | b))) begin
            $display("FAIL: universal_gates_behavioral.y_nor a=%b b=%b got=%b expected=%b", a, b, universal_gates_behavioral_y_nor, (~(a | b)));
            errors = errors + 1;
        end
        if (special_gates_switch_level_y_xor !== (a ^ b)) begin
            $display("FAIL: special_gates_switch_level.y_xor a=%b b=%b got=%b expected=%b", a, b, special_gates_switch_level_y_xor, (a ^ b));
            errors = errors + 1;
        end
        if (special_gates_switch_level_y_xnor !== (~(a ^ b))) begin
            $display("FAIL: special_gates_switch_level.y_xnor a=%b b=%b got=%b expected=%b", a, b, special_gates_switch_level_y_xnor, (~(a ^ b)));
            errors = errors + 1;
        end
        if (special_gates_gate_level_y_xor !== (a ^ b)) begin
            $display("FAIL: special_gates_gate_level.y_xor a=%b b=%b got=%b expected=%b", a, b, special_gates_gate_level_y_xor, (a ^ b));
            errors = errors + 1;
        end
        if (special_gates_gate_level_y_xnor !== (~(a ^ b))) begin
            $display("FAIL: special_gates_gate_level.y_xnor a=%b b=%b got=%b expected=%b", a, b, special_gates_gate_level_y_xnor, (~(a ^ b)));
            errors = errors + 1;
        end
        if (special_gates_dataflow_y_xor !== (a ^ b)) begin
            $display("FAIL: special_gates_dataflow.y_xor a=%b b=%b got=%b expected=%b", a, b, special_gates_dataflow_y_xor, (a ^ b));
            errors = errors + 1;
        end
        if (special_gates_dataflow_y_xnor !== (~(a ^ b))) begin
            $display("FAIL: special_gates_dataflow.y_xnor a=%b b=%b got=%b expected=%b", a, b, special_gates_dataflow_y_xnor, (~(a ^ b)));
            errors = errors + 1;
        end
        if (special_gates_behavioral_y_xor !== (a ^ b)) begin
            $display("FAIL: special_gates_behavioral.y_xor a=%b b=%b got=%b expected=%b", a, b, special_gates_behavioral_y_xor, (a ^ b));
            errors = errors + 1;
        end
        if (special_gates_behavioral_y_xnor !== (~(a ^ b))) begin
            $display("FAIL: special_gates_behavioral.y_xnor a=%b b=%b got=%b expected=%b", a, b, special_gates_behavioral_y_xnor, (~(a ^ b)));
            errors = errors + 1;
        end
    end
    endtask

    initial begin
        errors = 0;
        $display("Mission 100 - Project 001: Basic, Universal, and Special Gates");
        $display("Checking switch-level, gate-level, dataflow, and behavioral models...");

        a = 0; b = 0; #2; check_all();
        a = 0; b = 1; #2; check_all();
        a = 1; b = 0; #2; check_all();
        a = 1; b = 1; #2; check_all();

        if (errors == 0)
            $display("PASS: All gate outputs matched expected truth tables for all 4 input combinations.");
        else begin
            $display("FAIL: %0d mismatch(es) detected.", errors);
            $fatal(1, "Project 001 verification failed.");
        end
        $finish;
    end
endmodule
