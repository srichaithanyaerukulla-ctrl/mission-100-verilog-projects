# Project 001 — Logic Gates in Verilog HDL

**Mission 100 | Day 1 | Digital Logic Foundations**

This project implements three gate families in four modeling styles.

## Gate families

1. **Basic gates:** AND, OR, NOT
2. **Universal gates:** NAND, NOR
3. **Special gates:** XOR, XNOR

## Modeling styles

- Switch-level: MOS switch primitives (`pmos`, `nmos`, `cmos`)
- Gate-level: built-in Verilog gate primitives
- Dataflow: continuous `assign` statements
- Behavioral: combinational `always @(*)` blocks

Each category has a separate source file for each modeling style. The shared testbench instantiates all 12 implementations and checks every 2-input combination. The NOT gate is checked for both possible values of `a`.

## Repository layout

```text
project-001-logic-gates/
├── README.md
├── basic-gates/
├── universal-gates/
├── special-gates/
├── tb/tb_all_gates.v
├── simulation/
└── docs/
```

## Run simulation with Icarus Verilog

From this directory, run:

```bash
iverilog -g2012 -s tb_all_gates -o simulation/gates_sim \
  basic-gates/*.v universal-gates/*.v special-gates/*.v tb/tb_all_gates.v
vvp simulation/gates_sim
```

A successful run should print a `PASS` line. Switch-level support can vary by simulator; use a simulator supporting Verilog switch primitives for those files.

## Simulation images

`simulation/expected_waveforms.png` is a generated reference timing diagram derived from the expected truth tables. It is an illustration of expected signals, **not a screenshot captured from a simulator**. Capture your own simulator waveform after running the testbench and add it here if your workflow supports VCD/waveform viewing.

## Completion criteria

- [ ] All files compile in the selected simulator.
- [ ] Testbench passes for all input combinations.
- [ ] Intentional bug is introduced and detected, then corrected.
- [ ] Actual simulator output is recorded in `simulation/results.md`.
- [ ] Design notes are reviewed.

## Important modeling note

Behavioral and dataflow models are intended to describe combinational logic. Switch-level models are educational digital switch networks and do not simulate analog voltage, transistor sizing, or physical delays.
