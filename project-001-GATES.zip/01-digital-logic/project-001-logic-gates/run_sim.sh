#!/usr/bin/env bash
set -euo pipefail
mkdir -p simulation
iverilog -g2012 -s tb_all_gates -o simulation/gates_sim \
  basic-gates/*.v universal-gates/*.v special-gates/*.v tb/tb_all_gates.v
vvp simulation/gates_sim
