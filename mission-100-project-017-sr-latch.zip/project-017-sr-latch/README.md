# Project 017 — SR Latch Using Cross-Coupled NOR Gates

**Mission 100 Verilog Projects · Semiconductor-to-VLSI Journey · Project 017/100**

## Objective
SR Latch Using Cross-Coupled NOR Gates: implement the design and verify its behavior with a self-checking Verilog testbench.

## Theory
An SR latch stores one bit using feedback. For a NOR latch with active-HIGH Set S and Reset R: S=1 sets Q=1, R=1 resets Q=0, and S=R=0 holds the previous state. S=R=1 is invalid because both NOR outputs are forced LOW, breaking the normal complementary relation; release can be timing-dependent. The RTL model demonstrates set/reset/hold behavior and avoids testing the invalid condition. Real latches may exhibit metastability.

## Design approach
The RTL models functional logic or storage. It does not automatically reproduce analog transistor behavior, power, propagation delay, or metastability. Where a SPICE netlist is provided, it uses generic educational MOSFET models rather than a foundry-calibrated process model.

## Files
- `README.md` — theory and run instructions.
- `verilog/sr_latch.v` — Verilog implementation.
- `tb/tb_sr_latch.v` — self-checking testbench.
- No SPICE netlist is included because this project focuses on RTL sequential behavior.\n- `docs/design-notes.md` — design considerations.
- `simulation/results-template.md` — record actual results.

## Run Verilog
```sh
iverilog -g2012 -s tb_sr_latch -o sim_out verilog/sr_latch.v tb/tb_sr_latch.v
vvp sim_out
```

## Verification status
**Pending verification.** The files are packaged for execution, but no test or SPICE result is claimed until you run the simulator and inspect its output.
