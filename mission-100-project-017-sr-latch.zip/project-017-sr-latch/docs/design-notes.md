# Design Notes — Project 017

An SR latch stores one bit using feedback. For a NOR latch with active-HIGH Set S and Reset R: S=1 sets Q=1, R=1 resets Q=0, and S=R=0 holds the previous state. S=R=1 is invalid because both NOR outputs are forced LOW, breaking the normal complementary relation; release can be timing-dependent. The RTL model demonstrates set/reset/hold behavior and avoids testing the invalid condition. Real latches may exhibit metastability.

## Validation
- Run the included testbench.
- Review warnings and confirm expected state/logic transitions.
- For SPICE projects, inspect waveform and model assumptions.
