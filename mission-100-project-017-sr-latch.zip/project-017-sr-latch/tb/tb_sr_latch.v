`timescale 1ns/1ps
module tb_sr_latch; reg s,r; wire q,qn; integer e;
sr_latch dut(s,r,q,qn);
initial begin e=0;
s=0;r=1;#10;if(q!==0)e=e+1;
s=0;r=0;#10;if(q!==0)e=e+1;
s=1;r=0;#10;if(q!==1)e=e+1;
s=0;r=0;#10;if(q!==1)e=e+1;
if(e==0)$display("PASS: SR latch set/reset/hold");else $display("FAIL %0d",e);$finish;end endmodule