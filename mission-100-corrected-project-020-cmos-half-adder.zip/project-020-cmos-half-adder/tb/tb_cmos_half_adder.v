`timescale 1ns/1ps
module tb_cmos_half_adder;
reg a,b; wire sum,carry; integer errors;
cmos_half_adder dut(.a(a),.b(b),.sum(sum),.carry(carry));
task check(input reg av, input reg bv, input reg es, input reg ec);
begin a=av; b=bv; #10; if(sum!==es || carry!==ec) errors=errors+1; end endtask
initial begin errors=0;
check(0,0,0,0); check(0,1,1,0); check(1,0,1,0); check(1,1,0,1);
if(errors==0) $display("PASS: CMOS half adder truth table"); else $display("FAIL: %0d errors",errors); $finish; end
endmodule
