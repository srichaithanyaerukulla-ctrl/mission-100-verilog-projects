# Design Notes — Project 020: CMOS Half Adder

## Design theory
A half adder adds two one-bit inputs, A and B, and produces a Sum and Carry output. The Sum is XOR because it is HIGH when exactly one input is HIGH. Carry is AND because it is HIGH only when both inputs are HIGH.

Equations: `SUM = A ⊕ B`; `CARRY = A & B`. Truth table: 00→SUM=0,CARRY=0; 01→1,0; 10→1,0; 11→0,1. A half adder has no carry-in input, so it cannot by itself handle a carry from a previous bit position. It is a basic building block for multi-bit adders. The SPICE netlist composes transistor-level NAND-based XOR and AND subcircuits.

## Expected behavior
SUM is XOR; CARRY is AND. Only 11 generates a carry.

## Implementation cautions
## Model and verification limits
The SPICE examples use generic Level-1 MOSFET models with illustrative parameters; they are not vendor- or foundry-calibrated. The RTL modules represent Boolean functionality and do not calculate transistor current, analog delay, leakage, or physical power. Run the actual commands and inspect outputs before marking a project verified.
