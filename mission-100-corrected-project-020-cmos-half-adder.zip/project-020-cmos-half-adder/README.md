# Project 020 — CMOS Half Adder

**Mission 100 Verilog Projects · CMOS Logic Design · Project 020/100**

## Objective
Study **Sum and carry from two input bits** by understanding the transistor-level circuit, writing a functional Verilog model, and checking its truth table with a self-checking testbench.

## Theory
A half adder adds two one-bit inputs, A and B, and produces a Sum and Carry output. The Sum is XOR because it is HIGH when exactly one input is HIGH. Carry is AND because it is HIGH only when both inputs are HIGH.

Equations: `SUM = A ⊕ B`; `CARRY = A & B`. Truth table: 00→SUM=0,CARRY=0; 01→1,0; 10→1,0; 11→0,1. A half adder has no carry-in input, so it cannot by itself handle a carry from a previous bit position. It is a basic building block for multi-bit adders. The SPICE netlist composes transistor-level NAND-based XOR and AND subcircuits.

## Expected behavior
SUM is XOR; CARRY is AND. Only 11 generates a carry.

## Files
- `README.md` — theory and run guide.
- `verilog/cmos_half_adder.v` — Verilog implementation.
- `tb/tb_cmos_half_adder.v` — self-checking testbench.
- `spice/cmos_half_adder.cir` — illustrative transistor-level SPICE netlist.
- `docs/design-notes.md` — design considerations and limitations.
- `simulation/results-template.md` — record actual results.
- `.gitignore` — ignores generated outputs.

## Run Verilog
Run from this project folder:
```sh
iverilog -g2012 -s tb_cmos_half_adder -o sim_out verilog/cmos_half_adder.v tb/tb_cmos_half_adder.v
vvp sim_out
```

## Run SPICE
Requires ngspice:
```sh
ngspice -b spice/cmos_half_adder.cir
```
Inspect the simulator output and CSV file. SPICE syntax and model behavior may vary by simulator version.

## Model and verification limits
The SPICE examples use generic Level-1 MOSFET models with illustrative parameters; they are not vendor- or foundry-calibrated. The RTL modules represent Boolean functionality and do not calculate transistor current, analog delay, leakage, or physical power. Run the actual commands and inspect outputs before marking a project verified.

## GitHub destination
`mission-100-verilog-projects/02-cmos-logic/project-020-cmos-half-adder/`

## Verification status
**Pending verification.** These source files are prepared for execution, but the simulations have not been reported as run or passed.
