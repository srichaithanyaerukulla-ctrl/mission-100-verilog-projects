`timescale 1ns/1ps
module tb_cmos_transmission_gate; reg en,d; wire q; integer e;
cmos_transmission_gate dut(en,d,q);
initial begin e=0;
en=1; d=0; #10; if(q!==0) e=e+1;
en=1; d=1; #10; if(q!==1) e=e+1;
en=0; d=1; #10; if(q!==1'bz) e=e+1;
if(e==0) $display("PASS: transmission gate abstraction"); else $display("FAIL %0d",e); $finish; end endmodule