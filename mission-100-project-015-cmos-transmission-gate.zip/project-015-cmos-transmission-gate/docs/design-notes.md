# Design Notes — Project 015

A CMOS transmission gate places an NMOS and PMOS in parallel between two signal nodes. NMOS gate gets EN and PMOS gate gets ENB, the complement. When enabled, the pair passes signals bidirectionally; when disabled, both devices are intended to be off. NMOS alone passes a strong LOW but a degraded HIGH; PMOS alone passes a strong HIGH but a degraded LOW. Together, they improve the passed logic range. Transmission gates are used in muxes, latches, and sampled-data circuits.

## Validation
- Run the included testbench.
- Review warnings and confirm expected state/logic transitions.
- For SPICE projects, inspect waveform and model assumptions.
