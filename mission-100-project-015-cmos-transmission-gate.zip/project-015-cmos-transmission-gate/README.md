# Project 015 — CMOS Transmission Gate

**Mission 100 Verilog Projects · Semiconductor-to-VLSI Journey · Project 015/100**

## Objective
CMOS Transmission Gate: implement the design and verify its behavior with a self-checking Verilog testbench.

## Theory
A CMOS transmission gate places an NMOS and PMOS in parallel between two signal nodes. NMOS gate gets EN and PMOS gate gets ENB, the complement. When enabled, the pair passes signals bidirectionally; when disabled, both devices are intended to be off. NMOS alone passes a strong LOW but a degraded HIGH; PMOS alone passes a strong HIGH but a degraded LOW. Together, they improve the passed logic range. Transmission gates are used in muxes, latches, and sampled-data circuits.

## Design approach
The RTL models functional logic or storage. It does not automatically reproduce analog transistor behavior, power, propagation delay, or metastability. Where a SPICE netlist is provided, it uses generic educational MOSFET models rather than a foundry-calibrated process model.

## Files
- `README.md` — theory and run instructions.
- `verilog/cmos_transmission_gate.v` — Verilog implementation.
- `tb/tb_cmos_transmission_gate.v` — self-checking testbench.
- `spice/cmos_transmission_gate.cir` — illustrative transistor-level SPICE circuit.\n- `docs/design-notes.md` — design considerations.
- `simulation/results-template.md` — record actual results.

## Run Verilog
```sh
iverilog -g2012 -s tb_cmos_transmission_gate -o sim_out verilog/cmos_transmission_gate.v tb/tb_cmos_transmission_gate.v
vvp sim_out
```

## Run SPICE
```sh
ngspice -b spice/cmos_transmission_gate.cir
```
Inspect the log and generated CSV. Simulator syntax and model behavior can vary by version.

## Verification status
**Pending verification.** The files are packaged for execution, but no test or SPICE result is claimed until you run the simulator and inspect its output.
