# Design Notes — Project 011: CMOS Buffer

## Design theory
A logical buffer preserves the input value while isolating one stage from the next and improving drive capability. A common CMOS buffer is built from **two cascaded CMOS inverters**: the first inverts the input and the second restores the original polarity. Each inverter uses a PMOS pull-up connected to VDD and an NMOS pull-down connected to ground.

For a stable input LOW, the first stage output goes HIGH and the second stage output goes LOW; for a stable input HIGH, the first stage output goes LOW and the second stage output goes HIGH. The overall transfer is non-inverting (`Y = A`). In physical design, buffer stages can be sized to drive larger capacitive loads. The included RTL expresses only the Boolean function; synthesis may optimize it, so it does not guarantee two physical stages.

## Expected behavior
Output logic follows input; SPICE output passes through two inverter stages.

## Implementation cautions
## Model and verification limits
The SPICE examples use generic Level-1 MOSFET models with illustrative parameters; they are not vendor- or foundry-calibrated. The RTL modules represent Boolean functionality and do not calculate transistor current, analog delay, leakage, or physical power. Run the actual commands and inspect outputs before marking a project verified.
