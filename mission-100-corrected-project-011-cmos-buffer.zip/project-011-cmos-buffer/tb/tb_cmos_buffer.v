`timescale 1ns/1ps
module tb_cmos_buffer;
reg a; wire y; integer errors;
cmos_buffer dut(.a(a),.y(y));
initial begin
 errors=0; a=0; #10; if(y!==0) errors=errors+1;
 a=1; #10; if(y!==1) errors=errors+1;
 if(errors==0) $display("PASS: CMOS buffer preserves logic"); else $display("FAIL: %0d errors",errors);
 $finish;
end
endmodule
