# Project 011 — CMOS Buffer

**Mission 100 Verilog Projects · CMOS Logic Design · Project 011/100**

## Objective
Study **Transistor-level buffering** by understanding the transistor-level circuit, writing a functional Verilog model, and checking its truth table with a self-checking testbench.

## Theory
A logical buffer preserves the input value while isolating one stage from the next and improving drive capability. A common CMOS buffer is built from **two cascaded CMOS inverters**: the first inverts the input and the second restores the original polarity. Each inverter uses a PMOS pull-up connected to VDD and an NMOS pull-down connected to ground.

For a stable input LOW, the first stage output goes HIGH and the second stage output goes LOW; for a stable input HIGH, the first stage output goes LOW and the second stage output goes HIGH. The overall transfer is non-inverting (`Y = A`). In physical design, buffer stages can be sized to drive larger capacitive loads. The included RTL expresses only the Boolean function; synthesis may optimize it, so it does not guarantee two physical stages.

## Expected behavior
Output logic follows input; SPICE output passes through two inverter stages.

## Files
- `README.md` — theory and run guide.
- `verilog/cmos_buffer.v` — Verilog implementation.
- `tb/tb_cmos_buffer.v` — self-checking testbench.
- `spice/cmos_buffer.cir` — illustrative transistor-level SPICE netlist.
- `docs/design-notes.md` — design considerations and limitations.
- `simulation/results-template.md` — record actual results.
- `.gitignore` — ignores generated outputs.

## Run Verilog
Run from this project folder:
```sh
iverilog -g2012 -s tb_cmos_buffer -o sim_out verilog/cmos_buffer.v tb/tb_cmos_buffer.v
vvp sim_out
```

## Run SPICE
Requires ngspice:
```sh
ngspice -b spice/cmos_buffer.cir
```
Inspect the simulator output and CSV file. SPICE syntax and model behavior may vary by simulator version.

## Model and verification limits
The SPICE examples use generic Level-1 MOSFET models with illustrative parameters; they are not vendor- or foundry-calibrated. The RTL modules represent Boolean functionality and do not calculate transistor current, analog delay, leakage, or physical power. Run the actual commands and inspect outputs before marking a project verified.

## GitHub destination
`mission-100-verilog-projects/02-cmos-logic/project-011-cmos-buffer/`

## Verification status
**Pending verification.** These source files are prepared for execution, but the simulations have not been reported as run or passed.
