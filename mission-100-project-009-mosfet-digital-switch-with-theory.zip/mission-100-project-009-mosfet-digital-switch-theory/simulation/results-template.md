# Project 009 — Simulation Results (fill after running)

Date:  
ngspice version:  
Icarus Verilog version:  

## NMOS low-side switch
- Simulation command:
- Run successful? 
- Drain voltage with control LOW:
- Drain voltage with control HIGH:
- Load current with control HIGH:
- CSV generated:

## PMOS high-side switch
- Simulation command:
- Run successful?
- Drain voltage with control HIGH:
- Drain voltage with control LOW:
- Load current with control LOW:
- CSV generated:

## Verilog testbench
- Command:
- Number of PASS lines:
- Number of FAIL lines:
- Final result:
- VCD generated:

## Observations and conclusion
Record measured values and any unexpected behavior. Do not label expected values as measured results.
