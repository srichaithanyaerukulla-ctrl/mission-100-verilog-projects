# Project 009 — MOSFET as a Digital Switch

**Mission 100 Verilog Projects · Semiconductor Fundamentals · Project 009/100**

## Goal
Implement two practical switching circuits: an **NMOS low-side switch** and a **PMOS high-side switch**. Observe their load voltages in SPICE and implement a **digital-only functional abstraction** in Verilog.

## What you learn
1. How NMOS low-side and PMOS high-side switching differ.
2. Why gate-to-source voltage (`VGS`) rather than absolute gate voltage determines conduction.
3. Why a pull-down/pull-up is needed for a reliable OFF state.
4. How to drive an output load and measure transient switching in SPICE.
5. How to test functional switching behavior in Verilog without claiming it is transistor-level simulation.

## Theory: How a MOSFET works as a switch

A MOSFET (Metal-Oxide-Semiconductor Field-Effect Transistor) is a voltage-controlled device. The gate is insulated from the semiconductor channel by a thin oxide layer, so its electric field controls whether a conductive channel forms between drain and source. In switching applications, gate-drive voltages are chosen to put the device in an OFF state or a low-resistance ON state.

### 1. Gate-to-source voltage

The important control quantity is the gate voltage relative to the source:

`VGS = VG − VS`

- An enhancement NMOS turns ON when `VGS` is sufficiently positive.
- An enhancement PMOS turns ON when `VGS` is sufficiently negative.
- The exact gate voltage needed for low-resistance operation depends on the selected device. Threshold voltage alone does not guarantee that a MOSFET is fully enhanced.

### 2. NMOS low-side switch

The source is connected to ground, and the load sits between the positive supply and the drain.

- **Control HIGH:** `VGS` rises, the NMOS conducts, and the drain node is pulled close to ground. Current flows from the supply through the load and MOSFET to ground, energizing the load.
- **Control LOW:** the MOSFET turns OFF. The drain node is pulled toward the positive supply through the load, and load current becomes very small apart from leakage.

A gate pull-down resistor holds the gate LOW if the controller output is disconnected or high-impedance. A small series gate resistor can limit transient gate-charging current and reduce ringing.

### 3. PMOS high-side switch

The source is connected to the positive supply, and the load sits between the drain and ground.

- **Control LOW:** the gate is pulled below the source, making `VGS` sufficiently negative to turn the PMOS ON. The drain rises toward the positive supply and current flows through the load.
- **Control HIGH (near the source supply):** `VGS` approaches 0 V, the PMOS turns OFF, and the load is de-energized.

A gate pull-up to the PMOS source establishes the OFF state. The control signal must be compatible with the source voltage; a 0/5 V control scheme is suitable only for the illustrative 5 V circuit in this project.

### 4. Gate voltage versus load voltage

The control signal determines the switch state, but the load-node voltage depends on circuit topology:
- **NMOS low-side:** the drain node is LOW when ON and rises toward +5 V when OFF.
- **PMOS high-side:** the drain node rises toward +5 V when ON and falls toward ground when OFF.

These are expected steady-state behaviors for the included resistor-load circuits. Switching transients can be affected by capacitance and load properties.

### 5. SPICE versus Verilog

- **SPICE** simulates an electrical model and can show analog voltages, currents, and transient waveforms. The included device parameters are educational, not a datasheet-accurate model of a specific MOSFET.
- **Verilog** models the intended logical ON/OFF behavior only. It does not calculate channel current, on-resistance, capacitance, temperature effects, body-diode behavior, or analog switching delays.

Use SPICE to inspect electrical waveforms and Verilog to verify control-state logic. Do not mark either simulation as verified until you have actually run it and checked the outputs.

## Circuit A: NMOS low-side switch

```
+5 V --- 1 kΩ load --- D  NMOS  S --- GND
                         G <- 0/5 V control (through 100 Ω)
                         G --- 100 kΩ --- GND
```

`control = 1` -> NMOS ON -> drain/load-low node approximately 0 V -> load energized.
`control = 0` -> NMOS OFF -> drain/load-low node approximately +5 V -> load de-energized.

## Circuit B: PMOS high-side switch

```
+5 V --- S  PMOS  D --- 1 kΩ load --- GND
           G <- 5/0 V control (through 100 Ω)
           G --- 100 kΩ --- +5 V
```

`control = 0` -> PMOS ON -> drain/load-high node approximately +5 V -> load energized.
`control = 1` -> PMOS OFF -> drain/load-high node approximately 0 V -> load de-energized.

**Note:** PMOS control uses 0 V and +5 V levels; its ON command is active-low.

## File map
- `spice/nmos_low_side_switch.cir` — NMOS transient switching circuit.
- `spice/pmos_high_side_switch.cir` — PMOS transient switching circuit.
- `verilog/mosfet_digital_switch.v` — functional switch model (not an analog transistor model).
- `tb/tb_mosfet_digital_switch.v` — self-checking testbench.
- `docs/design-notes.md` — calculations, circuit design and safety limits.
- `simulation/results-template.md` — fill in after actual simulator runs.
- `.gitignore` — generated output exclusions.

## Run SPICE
Requires `ngspice`. Run from the project root:
```sh
ngspice -b spice/nmos_low_side_switch.cir
ngspice -b spice/pmos_high_side_switch.cir
```
The netlists write `nmos_switch_transient.csv` and `pmos_switch_transient.csv` to the current working directory. Each contains transient waveforms for gate, load node, and supply current; inspect the headers and sign convention in your ngspice version.

## Run Verilog
Requires `iverilog` and `vvp`:
```sh
iverilog -g2012 -s tb_mosfet_digital_switch -o switch_sim verilog/mosfet_digital_switch.v tb/tb_mosfet_digital_switch.v
vvp switch_sim
```
The testbench checks NMOS active-high and PMOS active-low switching and writes a VCD waveform. It is a functional digital model, not a MOSFET electrical simulation.

## GitHub path
`mission-100-verilog-projects/01-semiconductor-fundamentals/project-009-mosfet-digital-switch/`

## Status
**Pending verification:** these simulations are provided as runnable source files, but no actual simulator execution is claimed here.
