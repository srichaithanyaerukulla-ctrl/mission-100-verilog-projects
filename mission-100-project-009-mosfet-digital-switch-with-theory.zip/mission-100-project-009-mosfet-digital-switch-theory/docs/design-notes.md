# Design Notes — MOSFET as a Digital Switch

## NMOS low-side
- Supply: +5 V; load resistor: 1 kΩ between supply and drain.
- Source and body: ground; gate control: 0 V or +5 V.
- `VGS = VG - VS`: high gate voltage turns NMOS ON.
- A 100 kΩ gate-to-ground resistor helps keep the device OFF if the drive is disconnected.

## PMOS high-side
- Source and body: +5 V; load resistor: 1 kΩ between drain and ground.
- Gate control: +5 V (OFF) or 0 V (ON).
- `VGS = VG - VS`: a negative gate-to-source voltage turns PMOS ON.
- A 100 kΩ gate-to-source resistor helps keep the device OFF if the drive is disconnected.

## Approximate load current
With an ideal fully-ON switch, `Iload ≈ 5 V / 1000 Ω = 5 mA` and `Pload ≈ (5 V)^2 / 1000 Ω = 25 mW`. Real results depend on the device's on-resistance, model, and circuit.

## SPICE model and measurements
Both netlists use generic Level-1 MOSFET models with illustrative threshold voltages and dimensions; they are **not** validated real-device models. Examine gate voltage, drain voltage, and current over time. In SPICE, `i(VDD)` may be negative while the supply delivers current; the sign convention is current entering the voltage source's positive terminal.

## Limitations and practical precautions
- A gate series resistor can limit transient gate-drive current; it does not substitute for a proper gate driver in high-power/high-frequency designs.
- Do not connect an inductive load without considering flyback protection and device ratings.
- Check `VGS(max)`, `VDS(max)`, current, power, and logic-drive compatibility before selecting a real MOSFET.
- The Verilog modules are Boolean abstractions. They do **not** calculate drain current, switching speed, gate charge, dissipation, or analog node voltages.

## Verification checklist
1. Run both ngspice netlists and inspect their waveforms.
2. Verify NMOS drain node falls when its gate goes high.
3. Verify PMOS drain node rises when its gate goes low.
4. Run the Verilog testbench and check its printed PASS/FAIL result.
5. Fill in `simulation/results-template.md` with actual observations.
