`timescale 1ns/1ps
module tb_mosfet_digital_switch;
    reg control;
    wire n_load_on, n_drain_high;
    wire p_load_on, p_drain_high;
    integer errors;

    nmos_low_side_switch nmos (
        .control(control), .load_on(n_load_on), .drain_node_high(n_drain_high)
    );
    pmos_high_side_switch pmos (
        .control(control), .load_on(p_load_on), .drain_node_high(p_drain_high)
    );

    task check;
        input c;
        input expected_n_load;
        input expected_n_drain;
        input expected_p_load;
        input expected_p_drain;
        begin
            control = c;
            #10;
            if ({n_load_on,n_drain_high,p_load_on,p_drain_high} !==
                {expected_n_load,expected_n_drain,expected_p_load,expected_p_drain}) begin
                $display("FAIL control=%b got NMOS(load,drain)=%b%b PMOS(load,drain)=%b%b",
                         c,n_load_on,n_drain_high,p_load_on,p_drain_high);
                errors = errors + 1;
            end else begin
                $display("PASS control=%b NMOS(load,drain)=%b%b PMOS(load,drain)=%b%b",
                         c,n_load_on,n_drain_high,p_load_on,p_drain_high);
            end
        end
    endtask

    initial begin
        $dumpfile("mosfet_switch.vcd");
        $dumpvars(0, tb_mosfet_digital_switch);
        errors = 0;
        check(1'b0, 1'b0, 1'b1, 1'b1, 1'b1);
        check(1'b1, 1'b1, 1'b0, 1'b0, 1'b0);
        check(1'b0, 1'b0, 1'b1, 1'b1, 1'b1);
        if (errors == 0) $display("RESULT: ALL DIGITAL SWITCH CHECKS PASSED");
        else $display("RESULT: %0d CHECK(S) FAILED", errors);
        $finish;
    end
endmodule
