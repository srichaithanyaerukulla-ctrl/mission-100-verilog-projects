`timescale 1ns/1ps
module tb_mosfet_switch_models;
    reg gate_high;
    wire nmos_load_on;
    wire pmos_load_on;
    integer errors;

    nmos_low_side_switch u_nmos (
        .gate_high(gate_high), .load_on(nmos_load_on)
    );
    pmos_high_side_switch u_pmos (
        .gate_high(gate_high), .load_on(pmos_load_on)
    );

    task check;
        input gate;
        input expected_nmos;
        input expected_pmos;
        begin
            gate_high = gate;
            #10;
            if (nmos_load_on !== expected_nmos ||
                pmos_load_on !== expected_pmos) begin
                errors = errors + 1;
                $display("FAIL gate=%b NMOS=%b PMOS=%b", gate_high,
                         nmos_load_on, pmos_load_on);
            end else begin
                $display("PASS gate=%b NMOS=%b PMOS=%b", gate_high,
                         nmos_load_on, pmos_load_on);
            end
        end
    endtask

    initial begin
        errors = 0;
        $dumpfile("mosfet_switches.vcd");
        $dumpvars(0, tb_mosfet_switch_models);
        check(1'b0, 1'b0, 1'b1);
        check(1'b1, 1'b1, 1'b0);
        check(1'b0, 1'b0, 1'b1);
        if (errors == 0) $display("RESULT: ALL DIGITAL CHECKS PASSED");
        else $display("RESULT: %0d CHECK(S) FAILED", errors);
        $finish;
    end
endmodule
