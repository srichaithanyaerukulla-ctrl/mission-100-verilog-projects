// Project 009: Idealized switching-control abstractions.
// These modules do NOT model MOSFET analog voltages, currents or timing.
`timescale 1ns/1ps
module nmos_low_side_switch (
    input wire gate_high,
    output wire load_on
);
    assign load_on = gate_high;
endmodule

module pmos_high_side_switch (
    input wire gate_high,
    output wire load_on
);
    assign load_on = ~gate_high;
endmodule
