// Project 009 — digital FUNCTIONAL abstractions only.
// No MOSFET physics, gate charge, threshold, analog voltages or delays modeled.
`timescale 1ns/1ps
module nmos_low_side_switch (
    input  wire control,
    output wire load_on,
    output wire drain_node_high
);
    assign load_on = control;             // active-high control
    assign drain_node_high = ~control;    // ideal resistive pull-up when OFF
endmodule

module pmos_high_side_switch (
    input  wire control,
    output wire load_on,
    output wire drain_node_high
);
    assign load_on = ~control;            // active-low control
    assign drain_node_high = ~control;    // ideal load pull-down when OFF
endmodule
