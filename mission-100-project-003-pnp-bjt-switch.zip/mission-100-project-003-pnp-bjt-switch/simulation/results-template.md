# Simulation Results — Project 003

**Status: Not yet verified. Fill this in after running the simulators.**

## SPICE
- Simulator/version:
- Command:
- Simulation completed?:
- Collector voltage when control is LOW:
- Collector voltage when control is HIGH:
- Observed transition behavior:
- Screenshot/log filename:

## Verilog digital abstraction
- Simulator/version:
- Command:
- Testbench result:
- Screenshot/log filename:

## Interpretation
Explain why a PNP transistor turns ON when its base is pulled below its emitter.

## Limitations
The Verilog model is digital-only; it does not model analog current, voltage, transistor gain, saturation, or switching delay.
