# Project 003 — PNP BJT as a High-Side Switch

**Mission 100: Semiconductor-to-VLSI Journey**  
**Level:** Semiconductor and Transistor Fundamentals  
**Project:** 003 / 100  
**Status:** Prepared; run simulations before marking verified.

## Objective
Study a PNP bipolar junction transistor (BJT) as a high-side switch using SPICE, then compare it with a digital Verilog abstraction.

## Circuit
- Q1: PNP transistor using an educational 2N2907-style model
- Supply: 5 V; emitter connected to +5 V
- Collector load: 1 kΩ to ground
- Base resistor: 10 kΩ from control input to base
- Control input: 0-to-5 V pulse

**Control LOW:** base is pulled below emitter, PNP turns ON, collector rises toward the supply.  
**Control HIGH (near +5 V):** base and emitter are at approximately the same voltage, PNP turns OFF, and the load resistor pulls the collector toward ground.

This is an educational circuit. The 0–5 V control is appropriate here because the emitter supply is 5 V. For other supply/control levels, use a suitable driver and check the transistor's base-emitter reverse-voltage rating.

## Files
- `spice/pnp_bjt_switch.cir`: ngspice transient netlist
- `verilog/pnp_bjt_switch_model.v`: digital functional abstraction, not a physical transistor model
- `tb/tb_pnp_bjt_switch.v`: self-checking testbench
- `docs/design-notes.md`: operation and approximate calculations
- `simulation/results-template.md`: record actual simulation results

## Run SPICE
With ngspice installed:
```bash
ngspice -b spice/pnp_bjt_switch.cir
```
The netlist attempts to write `pnp_bjt_switch.csv` in the working directory. If needed, run interactively and plot `v(ctrl)`, `v(base)`, and `v(col)`.

## Run the Verilog digital abstraction
With Icarus Verilog installed:
```bash
iverilog -g2005 -o pnp_model_sim verilog/pnp_bjt_switch_model.v tb/tb_pnp_bjt_switch.v
vvp pnp_model_sim
```

Expected digital behavior:
- ctrl=0 -> transistor_on=1, collector_logic=1
- ctrl=1 -> transistor_on=0, collector_logic=0

The Verilog abstraction does not simulate base current, transistor gain, saturation voltage, analog voltages, or switching delay. Use SPICE for electrical behavior.

## Completion checklist
- [ ] Identify base, collector, and emitter
- [ ] Explain why LOW control turns the PNP ON
- [ ] Run the SPICE simulation and inspect voltages
- [ ] Run the Verilog testbench
- [ ] Save actual simulator logs/screenshots
- [ ] Complete `simulation/results-template.md`

## Safety
For physical construction, verify the transistor pinout and ratings from its datasheet, use current-limiting resistors, and never connect this low-voltage circuit directly to mains voltage.
