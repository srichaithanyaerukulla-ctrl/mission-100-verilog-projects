`timescale 1ns/1ps

module tb_pnp_bjt_switch;
    reg ctrl;
    wire transistor_on;
    wire collector_logic;
    integer errors;

    pnp_bjt_switch_model dut (
        .ctrl(ctrl),
        .transistor_on(transistor_on),
        .collector_logic(collector_logic)
    );

    initial begin
        errors = 0;
        $display("ctrl | transistor_on | collector_logic");

        ctrl = 1'b0; #10;
        $display("  %b  |       %b       |       %b",
                 ctrl, transistor_on, collector_logic);
        if (transistor_on !== 1'b1 || collector_logic !== 1'b1)
            errors = errors + 1;

        ctrl = 1'b1; #10;
        $display("  %b  |       %b       |       %b",
                 ctrl, transistor_on, collector_logic);
        if (transistor_on !== 1'b0 || collector_logic !== 1'b0)
            errors = errors + 1;

        if (errors == 0)
            $display("PASS: Digital abstraction matches expected states.");
        else
            $display("FAIL: %0d error(s).", errors);
        $finish;
    end
endmodule
