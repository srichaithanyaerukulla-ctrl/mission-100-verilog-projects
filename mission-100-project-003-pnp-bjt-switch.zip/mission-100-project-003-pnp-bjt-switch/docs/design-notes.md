# Design Notes — PNP BJT High-Side Switch

## Terminals and topology
- Emitter (E): connected to +5 V.
- Collector (C): connected to the load resistor, which returns to ground.
- Base (B): driven through a 10 kΩ resistor.

## OFF state
When control is near +5 V, base is near emitter potential. The base-emitter junction is not appreciably forward-biased, so the transistor is OFF. The load resistor pulls the collector toward ground.

## ON state
When control is LOW (0 V), the base is pulled below the emitter. The base-emitter junction becomes forward-biased and the PNP conducts, sourcing current from +5 V through the transistor and load to ground. With sufficient base current, it saturates.

## First-order estimates
Assuming |VBE| ≈ 0.7 V:
IB ≈ (5 V - 0.7 V) / 10 kΩ ≈ 0.43 mA.

Assuming a saturated collector-emitter drop around 0.2 V:
IL ≈ (5 V - 0.2 V) / 1 kΩ ≈ 4.8 mA.

These are rough estimates. Actual values depend on the model, temperature, and transistor characteristics. Check the selected part's datasheet before physical construction.

## Digital abstraction limitation
The Verilog model maps control logic to ideal states only. It does not model analog voltages, current, gain, saturation, reverse breakdown, or switching delays. Use SPICE for electrical simulation.
