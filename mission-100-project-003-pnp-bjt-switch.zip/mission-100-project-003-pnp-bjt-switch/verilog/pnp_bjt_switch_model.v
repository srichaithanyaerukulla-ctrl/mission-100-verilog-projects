// Functional digital abstraction of a PNP high-side switch.
// NOT a transistor-level BJT electrical model.
module pnp_bjt_switch_model (
    input  wire ctrl,
    output wire transistor_on,
    output wire collector_logic
);
    // In this circuit, LOW control turns the PNP ON.
    assign transistor_on = ~ctrl;
    assign collector_logic = ~ctrl;
endmodule
