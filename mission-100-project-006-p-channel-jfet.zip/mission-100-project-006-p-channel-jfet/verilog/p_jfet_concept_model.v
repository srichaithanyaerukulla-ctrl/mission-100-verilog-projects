`timescale 1ns/1ps

// Educational DIGITAL abstraction of a P-channel JFET.
// vgs_mv is a non-negative gate-to-source voltage in millivolts.
// Increasing positive VGS represents stronger reverse bias for this P-channel device.
// This is not a semiconductor/analog model and is not intended for circuit signoff.

module p_jfet_concept_model (
    input  wire [11:0] vgs_mv,
    input  wire        supply_enabled,
    output reg  [1:0]  conduction_level
);
    // conduction_level encoding:
    // 2'b00 = OFF, 2'b01 = LOW, 2'b10 = MEDIUM, 2'b11 = HIGH
    // These thresholds are illustrative teaching bins only.
    always @* begin
        if (!supply_enabled)
            conduction_level = 2'b00;
        else if (vgs_mv >= 12'd2000)
            conduction_level = 2'b00;
        else if (vgs_mv >= 12'd1200)
            conduction_level = 2'b01;
        else if (vgs_mv >= 12'd500)
            conduction_level = 2'b10;
        else
            conduction_level = 2'b11;
    end
endmodule
