# Simulation Results — Project 006

> Fill this file only after running the simulations. No measured or simulator-generated result is prefilled.

## Environment
- OS:
- ngspice version:
- Icarus Verilog version:
- Date run:

## SPICE sweep
- Command:
- Output file created? (Yes/No):
- VGS sweep observed (start/end/step):
- Does the magnitude of drain current decrease as positive VGS increases? (Yes/No/Needs investigation):
- Approximate cutoff behavior observed:
- Notes / screenshot filename:

## Verilog testbench
- Command:
- Console output:
- All conceptual checks passed? (Yes/No):
- Notes:

## Conclusion
Write 2–4 sentences based on your actual outputs. Explain how the depletion region and channel-current magnitude change as positive gate-to-source bias increases.

## Verification status
- [ ] Files reviewed
- [ ] SPICE run checked
- [ ] Verilog testbench run checked
- [ ] Results saved
