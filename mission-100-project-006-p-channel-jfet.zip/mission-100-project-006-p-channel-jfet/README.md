# Project 006 — P-Channel JFET Fundamentals

**Mission:** Mission 100 Verilog Projects  
**Track:** Semiconductor Fundamentals → Device Characteristics  
**Status:** Educational package prepared; simulations have not been independently run in this environment.

## Goal
Study how a P-channel junction field-effect transistor (JFET) controls current through a p-type channel using the gate-to-source voltage, then represent the trend with a deliberately simplified Verilog abstraction.

## What is included

```text
mission-100-project-006-p-channel-jfet/
├── README.md
├── .gitignore
├── spice/
│   └── p_channel_jfet.cir
├── verilog/
│   └── p_jfet_concept_model.v
├── tb/
│   └── tb_p_jfet_concept_model.v
├── docs/
│   └── design-notes.md
└── simulation/
    └── results-template.md
```

## Device concept
- Terminals: **Gate (G), Drain (D), Source (S)**.
- A P-channel JFET has a p-type channel and an n-type gate region.
- To reverse-bias the gate-channel junction, the gate is made more positive than the source.
- As positive **VGS** increases, the depletion region widens into the channel and the magnitude of drain current decreases.
- At the device's cutoff voltage, the channel current becomes very small. The exact cutoff point depends on the real device and model.

For the supplied illustrative circuit, the source is held at +5 V and the gate is swept from +5 V to +8 V. Therefore, **VGS = VG − VS** changes from 0 V to +3 V.

## Run the SPICE sweep
Install ngspice, then run from this project directory:

```bash
ngspice -b spice/p_channel_jfet.cir
```

The netlist asks ngspice to sweep the gate source from 5 V to 8 V in 0.1 V steps and write data to `p_channel_jfet_transfer.dat`. The sign of the reported supply current depends on SPICE's current-reference convention; inspect its magnitude and trend rather than assuming its sign.

## Run the Verilog concept test
Install Icarus Verilog, then run from this project directory:

```bash
iverilog -g2005 -o p_jfet_sim verilog/p_jfet_concept_model.v tb/tb_p_jfet_concept_model.v
vvp p_jfet_sim
```

The testbench checks the expected *qualitative* behavior: a small VGS has a stronger conceptual channel, increasing VGS lowers the conduction level, and a sufficiently large VGS or disabled supply is represented as OFF.

## Important limitation
The SPICE model and thresholds are educational approximations, not a validated model for a named commercial component. The Verilog module is a digital abstraction for learning and testbench practice; **it does not simulate semiconductor physics or replace SPICE**. Do not treat either model as a component-selection or hardware-design reference.

## Suggested GitHub location
`mission-100-verilog-projects/01-semiconductor-fundamentals/project-006-p-channel-jfet/`

## Completion checklist
- [ ] Commit the project files to GitHub.
- [ ] Run the ngspice sweep and retain the generated data/plot.
- [ ] Run the Verilog testbench and record the console output.
- [ ] Fill `simulation/results-template.md` with your actual results.
- [ ] Mark the project verified only after checking the real simulator outputs.
