# Design Notes — P-Channel JFET

## 1. Operating principle
A JFET uses the electric field created by its gate-channel junction to vary the width of the conducting channel. In a P-channel JFET, the channel is p-type and the gate region is n-type. Reverse bias is increased by making the gate more positive than the source.

## 2. Supplied SPICE setup
- Supply/source node: +5 V
- Drain resistor: 1 kΩ to ground
- Gate source: swept from +5 V to +8 V
- Thus VGS = VG − VS sweeps from 0 V to +3 V
- Illustrative model: `PJF (VTO=2 BETA=2m LAMBDA=0.02)`

As VGS rises, the depletion region expands and channel-current magnitude should decrease toward cutoff. A simulated result depends on the simulator and model implementation; examine the actual curve rather than relying only on the nominal VTO parameter.

## 3. Verilog abstraction
The module maps VGS, expressed in millivolts, into four conduction bins. It is useful for practicing combinational RTL, module interfaces, and a testbench. It is not an electrical simulation: it has no current, voltage-node solution, capacitances, temperature dependence, or physical units beyond the input convention.

## 4. Verification discipline
1. Run the SPICE sweep and inspect the generated data.
2. Confirm that increased positive VGS reduces the magnitude of current in the chosen model.
3. Run the Verilog testbench and capture the actual terminal output.
4. Record tool versions and findings in `simulation/results-template.md`.
5. If the SPICE trend differs, inspect the PJFET model parameters, terminal order, sweep direction, and simulator documentation. Do not silently edit the expected behavior to force a pass.

## 5. Safety and scope
This is a learning exercise, not a production design. Use a vendor's validated model and datasheet for real hardware work.
