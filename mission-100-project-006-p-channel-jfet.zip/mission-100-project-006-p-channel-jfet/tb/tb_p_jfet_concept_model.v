`timescale 1ns/1ps

module tb_p_jfet_concept_model;
    reg  [11:0] vgs_mv;
    reg         supply_enabled;
    wire [1:0]  conduction_level;
    integer errors;

    p_jfet_concept_model dut (
        .vgs_mv(vgs_mv),
        .supply_enabled(supply_enabled),
        .conduction_level(conduction_level)
    );

    task check_level;
        input [11:0] test_vgs_mv;
        input        test_supply;
        input [1:0]  expected_level;
        input [8*32:1] label_text;
        begin
            vgs_mv = test_vgs_mv;
            supply_enabled = test_supply;
            #10;
            if (conduction_level !== expected_level) begin
                $display("FAIL: %0s | VGS=%0d mV supply=%b expected=%b got=%b",
                         label_text, test_vgs_mv, test_supply,
                         expected_level, conduction_level);
                errors = errors + 1;
            end else begin
                $display("PASS: %0s | VGS=%0d mV level=%b",
                         label_text, test_vgs_mv, conduction_level);
            end
        end
    endtask

    initial begin
        errors = 0;
        vgs_mv = 0;
        supply_enabled = 1'b0;
        #10;

        check_level(12'd0,    1'b1, 2'b11, "near-zero VGS: HIGH");
        check_level(12'd500,  1'b1, 2'b10, "moderate VGS: MEDIUM");
        check_level(12'd1500, 1'b1, 2'b01, "higher VGS: LOW");
        check_level(12'd2000, 1'b1, 2'b00, "cutoff threshold: OFF");
        check_level(12'd2500, 1'b1, 2'b00, "above threshold: OFF");
        check_level(12'd0,    1'b0, 2'b00, "supply disabled: OFF");

        if (errors == 0)
            $display("ALL CONCEPTUAL TESTS PASSED");
        else
            $display("TESTS FAILED: %0d error(s)", errors);
        $finish;
    end
endmodule
