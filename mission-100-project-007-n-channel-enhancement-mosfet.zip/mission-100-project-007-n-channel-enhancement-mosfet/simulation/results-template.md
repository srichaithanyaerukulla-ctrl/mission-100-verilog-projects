# Simulation Results — Project 007

**Date:**  
**ngspice version:**  
**Icarus Verilog version:**  

## SPICE DC sweep
- Command executed:
- Did the netlist run without errors?
- Drain voltage at VGS = 0 V:
- Drain voltage around VGS = 2 V:
- Drain voltage at VGS = 5 V:
- CSV generated:
- Notes / unexpected behavior:

## Verilog testbench
- Command executed:
- PASS checks:
- FAIL checks:
- Final result line:
- Notes:

## Conclusion
Write a short conclusion from the actual outputs. Do not copy expected behavior as if it were measured.
