# Project 007 — N-Channel Enhancement MOSFET Fundamentals

**Mission 100 Verilog Projects | Semiconductor Fundamentals**

## Objective
Explore how an N-channel enhancement MOSFET behaves as its gate-to-source voltage (`VGS`) rises above threshold. This package combines an educational SPICE DC sweep with a simplified Verilog switching abstraction.

## Learning outcomes
- Identify gate, drain, and source terminals.
- Distinguish enhancement-mode from depletion-mode devices.
- Explain threshold voltage and channel formation.
- Observe drain voltage/current as `VGS` changes.
- Understand why the Verilog module is a digital abstraction, not a transistor-level model.

## Circuit
A generic Level-1 NMOS model, 5 V drain supply through 1 kΩ, source at ground, and gate swept from 0 V to 5 V. Parameters are illustrative, not tied to a commercial MOSFET.

## Files
- `spice/nmos_enhancement_sweep.cir` — ngspice DC sweep.
- `verilog/nmos_enhancement_model.v` — simplified digital abstraction.
- `tb/tb_nmos_enhancement_model.v` — self-checking testbench.
- `docs/design-notes.md` — theory and limitations.
- `simulation/results-template.md` — record actual results.
- `.gitignore` — excludes generated files.

## Run SPICE
From the project directory:
```bash
ngspice -b spice/nmos_enhancement_sweep.cir
```
The netlist writes `nmos_transfer.csv` in the working directory. Review the actual log and CSV.

## Run Verilog
Requires Icarus Verilog:
```bash
iverilog -g2005 -o nmos_sim verilog/nmos_enhancement_model.v tb/tb_nmos_enhancement_model.v
vvp nmos_sim
```

## Expected conceptual behavior
- `VGS` below threshold: OFF.
- `VGS` above threshold: ON.
- The testbench checks only the digital abstraction, not analog drain current or SPICE behavior.

## Repository destination
`mission-100-verilog-projects/01-semiconductor-fundamentals/project-007-n-channel-enhancement-mosfet/`

## Status
Simulation status: **Pending local run**. Do not mark verified until both commands have been run and their outputs reviewed.
