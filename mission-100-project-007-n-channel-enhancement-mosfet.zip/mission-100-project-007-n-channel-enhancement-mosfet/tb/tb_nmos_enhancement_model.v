`timescale 1ns/1ps
module tb_nmos_enhancement_model;
    real vgs;
    wire drain_on;
    integer errors;

    nmos_enhancement_model #(.VTH(2.0)) dut (.vgs(vgs), .drain_on(drain_on));

    initial begin
        errors = 0;
        $display("Project 007: N-channel enhancement MOSFET conceptual checks");
        vgs = 0.0; #10;
        if (drain_on !== 1'b0) begin $display("FAIL: expected OFF at VGS=0 V"); errors=errors+1; end
        else $display("PASS: OFF at VGS=0 V");
        vgs = 1.5; #10;
        if (drain_on !== 1'b0) begin $display("FAIL: expected OFF below threshold"); errors=errors+1; end
        else $display("PASS: OFF below threshold");
        vgs = 2.5; #10;
        if (drain_on !== 1'b1) begin $display("FAIL: expected ON above threshold"); errors=errors+1; end
        else $display("PASS: ON above threshold");
        vgs = 5.0; #10;
        if (drain_on !== 1'b1) begin $display("FAIL: expected ON at VGS=5 V"); errors=errors+1; end
        else $display("PASS: ON at VGS=5 V");
        if (errors == 0) $display("RESULT: ALL CONCEPTUAL CHECKS PASSED");
        else $display("RESULT: %0d CHECK(S) FAILED", errors);
        $finish;
    end
endmodule
