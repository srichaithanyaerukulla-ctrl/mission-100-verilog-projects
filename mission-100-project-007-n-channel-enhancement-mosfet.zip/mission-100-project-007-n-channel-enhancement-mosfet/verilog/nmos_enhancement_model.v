// Simplified digital abstraction, NOT a transistor-level/analog MOSFET model.
`timescale 1ns/1ps
module nmos_enhancement_model #(
    parameter real VTH = 2.0
) (
    input real vgs,
    output reg drain_on
);
    always @(*) begin
        if (vgs >= VTH) drain_on = 1'b1;
        else drain_on = 1'b0;
    end
endmodule
