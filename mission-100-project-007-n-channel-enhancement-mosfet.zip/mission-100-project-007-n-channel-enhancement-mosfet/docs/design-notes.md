# Design Notes — N-Channel Enhancement MOSFET

## Terminal roles
- **Gate (G):** controls channel formation through an electric field.
- **Drain (D):** terminal through which conventional drain current is commonly defined as entering an NMOS.
- **Source (S):** reference terminal for `VGS` in this example.

## Enhancement-mode operation
An enhancement NMOS has no strong inversion channel at `VGS = 0` in the idealized model. When `VGS` rises above threshold voltage `VTH`, an inversion channel forms and drain current can flow, subject to drain-source voltage and the load.

The Level-1 SPICE model uses illustrative parameters: `VTO=2 V`, `KP=100 µA/V²`, and `LAMBDA=0.02`. These are educational values, not guaranteed specifications for a real part. The 1 kΩ drain resistor limits current and affects the drain voltage.

## Digital abstraction
The Verilog model uses a threshold comparison to produce an ON/OFF signal. It omits subthreshold leakage, output resistance, body effect, capacitance, temperature dependence, switching delay, and current-voltage behavior. It is useful for practicing a behavioral abstraction and testbench structure only.

## Suggested observations
1. At low `VGS`, the drain node should remain near the supply because the MOSFET is off.
2. As `VGS` passes the model threshold, drain voltage should fall as the MOSFET conducts through `RD`.
3. Compare the qualitative SPICE curve with the Verilog threshold decision; do not expect numeric equivalence.
