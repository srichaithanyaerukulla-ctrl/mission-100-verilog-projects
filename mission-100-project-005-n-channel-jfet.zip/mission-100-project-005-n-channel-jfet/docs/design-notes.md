# Design Notes — N-Channel JFET

## Terminals
- Gate (G): control terminal forming a PN junction with the channel.
- Drain (D): current enters/leaves this terminal depending on sign conventions; in the shown N-channel circuit, conventional drain current flows from drain toward source.
- Source (S): reference end of the channel, at ground in this example.

## Operating principle
An N-channel JFET uses a reverse-biased gate-channel PN junction to control the width of a conductive channel. Making VGS more negative expands the depletion region, narrows the channel, and reduces drain current.

## Shockley equation (idealized transfer curve)
For a JFET in its saturation/constant-current region, an idealized approximation is:
ID = IDSS * (1 - VGS / VGS(off))^2
for VGS between 0 and VGS(off), with VGS(off) negative for an N-channel JFET.

The exact curve depends on the actual device and model; use the datasheet and SPICE results rather than treating the equation as exact.

## SPICE model note
The supplied model is illustrative. Model parameter conventions can vary among SPICE implementations, so confirm the sweep behaves sensibly in your installed ngspice version.

## Verilog model limitation
The Verilog module only represents an abstract ON/OFF concept. It does not model analog drain current, pinch-off, transconductance, channel resistance, capacitances, or temperature.
