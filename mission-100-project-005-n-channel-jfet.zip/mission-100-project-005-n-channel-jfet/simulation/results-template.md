# Simulation Results — Project 005

**Status: Not yet verified. Complete after running simulations.**

## SPICE
- Simulator/version:
- Command:
- Simulation completed?:
- Drain current at VGS = 0 V:
- Drain current at VGS = -1 V:
- Drain current at VGS = -2 V:
- Drain voltage at VGS = 0 V:
- Does current decrease as VGS becomes more negative?:
- Screenshot/log filename:

## Verilog conceptual model
- Simulator/version:
- Command:
- Testbench result:
- Screenshot/log filename:

## Interpretation
Explain how the reverse-biased gate-channel junction controls the channel width.

## Limitations
The Verilog model is conceptual only and does not simulate JFET electrical characteristics.
