# Project 005 — N-Channel JFET Fundamentals

**Mission 100: Semiconductor-to-VLSI Journey**  
**Project:** 005 / 100  
**Level:** Semiconductor and Transistor Fundamentals  
**Status:** Prepared; run simulation before marking verified.

## Objective
Study an N-channel JFET (Junction Field-Effect Transistor), understand its gate-controlled channel, and simulate its drain current as the gate-source voltage changes.

## Circuit and model
This project uses an educational SPICE JFET model, not a guaranteed model for a particular physical part:
- Drain supply: 5 V through RD = 1 kΩ
- Source: ground
- Gate bias: swept from 0 V toward negative voltage
- Device model: `NJFET_EDU` with VTO = -2 V and BETA = 2 mA/V²

For an N-channel JFET, the gate-source junction is normally reverse-biased. Making VGS more negative narrows the channel and reduces drain current. At a sufficiently negative cutoff voltage, the channel current approaches zero.

## Files
- `spice/n_channel_jfet.cir`: DC sweep netlist
- `verilog/jfet_concept_model.v`: conceptual digital abstraction only
- `tb/tb_jfet_concept_model.v`: testbench
- `docs/design-notes.md`: JFET theory and equations
- `simulation/results-template.md`: actual result log template

## Run SPICE
With ngspice installed:
```bash
ngspice -b spice/n_channel_jfet.cir
```
The netlist attempts to write `jfet_sweep.csv`. If your simulator reports a model or syntax issue, run it interactively and adapt the netlist to that ngspice version.

## Run the Verilog conceptual model
With Icarus Verilog installed:
```bash
iverilog -g2005 -o jfet_concept_sim verilog/jfet_concept_model.v tb/tb_jfet_concept_model.v
vvp jfet_concept_sim
```
This Verilog model maps a simplified two-state control to a conceptual ON/OFF result. It is not a JFET electrical model and cannot simulate current, voltage, transconductance, pinch-off curves, or temperature effects. Use SPICE for device characteristics.

## Completion checklist
- [ ] Identify gate, drain, and source
- [ ] Explain why the gate-source junction is reverse-biased in normal operation
- [ ] Run the SPICE sweep and inspect drain current versus gate voltage
- [ ] Run the Verilog testbench
- [ ] Record actual simulator version and results
- [ ] Save genuine screenshots/logs
- [ ] Complete `simulation/results-template.md`

## Safety
This is a low-voltage simulation. For physical experiments, use a real device datasheet, respect maximum gate-source voltage, and avoid forward-biasing the gate junction beyond safe current limits.
