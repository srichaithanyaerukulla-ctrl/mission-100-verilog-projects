// Simplified educational logic abstraction of an N-channel JFET.
// NOT an electrical JFET model. Use SPICE for I_D versus V_GS behavior.
module jfet_concept_model (
    input  wire gate_bias_cutoff, // 1 means gate bias is sufficiently negative
    output wire channel_conducting
);
    assign channel_conducting = ~gate_bias_cutoff;
endmodule
