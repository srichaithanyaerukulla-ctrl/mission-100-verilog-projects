`timescale 1ns/1ps

module tb_jfet_concept_model;
    reg gate_bias_cutoff;
    wire channel_conducting;
    integer errors;

    jfet_concept_model dut (
        .gate_bias_cutoff(gate_bias_cutoff),
        .channel_conducting(channel_conducting)
    );

    initial begin
        errors = 0;
        gate_bias_cutoff = 1'b0; #10;
        if (channel_conducting !== 1'b1) errors = errors + 1;

        gate_bias_cutoff = 1'b1; #10;
        if (channel_conducting !== 1'b0) errors = errors + 1;

        if (errors == 0)
            $display("PASS: JFET conceptual state checks passed.");
        else
            $display("FAIL: %0d error(s).", errors);
        $display("NOTE: This does not verify JFET electrical characteristics; use SPICE.");
        $finish;
    end
endmodule
