# Design Notes — Project 019: CMOS 2:1 Multiplexer

## Design theory
A 2:1 multiplexer selects D0 or D1 using select signal S. Its Boolean equation is `Y = (~S & D0) | (S & D1)`. When S=0, D0 is selected; when S=1, D1 is selected.

At transistor level, a transmission-gate mux uses two parallel branches, each formed from an NMOS and PMOS in parallel. Complementary enable controls turn one branch ON while the other is OFF. The NMOS control and PMOS control of each transmission gate are complementary. This helps pass both logic levels more effectively than a single NMOS pass transistor. The RTL verifies logical selection but does not model on-resistance, charge injection, or analog delays.

## Expected behavior
When S=0 the output follows D0; when S=1 it follows D1.

## Implementation cautions
## Model and verification limits
The SPICE examples use generic Level-1 MOSFET models with illustrative parameters; they are not vendor- or foundry-calibrated. The RTL modules represent Boolean functionality and do not calculate transistor current, analog delay, leakage, or physical power. Run the actual commands and inspect outputs before marking a project verified.
