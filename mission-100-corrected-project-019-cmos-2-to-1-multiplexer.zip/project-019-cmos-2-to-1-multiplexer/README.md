# Project 019 — CMOS 2:1 Multiplexer

**Mission 100 Verilog Projects · CMOS Logic Design · Project 019/100**

## Objective
Study **Transistor-level selection** by understanding the transistor-level circuit, writing a functional Verilog model, and checking its truth table with a self-checking testbench.

## Theory
A 2:1 multiplexer selects D0 or D1 using select signal S. Its Boolean equation is `Y = (~S & D0) | (S & D1)`. When S=0, D0 is selected; when S=1, D1 is selected.

At transistor level, a transmission-gate mux uses two parallel branches, each formed from an NMOS and PMOS in parallel. Complementary enable controls turn one branch ON while the other is OFF. The NMOS control and PMOS control of each transmission gate are complementary. This helps pass both logic levels more effectively than a single NMOS pass transistor. The RTL verifies logical selection but does not model on-resistance, charge injection, or analog delays.

## Expected behavior
When S=0 the output follows D0; when S=1 it follows D1.

## Files
- `README.md` — theory and run guide.
- `verilog/cmos_2_to_1_multiplexer.v` — Verilog implementation.
- `tb/tb_cmos_2_to_1_multiplexer.v` — self-checking testbench.
- `spice/cmos_2_to_1_multiplexer.cir` — illustrative transistor-level SPICE netlist.
- `docs/design-notes.md` — design considerations and limitations.
- `simulation/results-template.md` — record actual results.
- `.gitignore` — ignores generated outputs.

## Run Verilog
Run from this project folder:
```sh
iverilog -g2012 -s tb_cmos_2_to_1_multiplexer -o sim_out verilog/cmos_2_to_1_multiplexer.v tb/tb_cmos_2_to_1_multiplexer.v
vvp sim_out
```

## Run SPICE
Requires ngspice:
```sh
ngspice -b spice/cmos_2_to_1_multiplexer.cir
```
Inspect the simulator output and CSV file. SPICE syntax and model behavior may vary by simulator version.

## Model and verification limits
The SPICE examples use generic Level-1 MOSFET models with illustrative parameters; they are not vendor- or foundry-calibrated. The RTL modules represent Boolean functionality and do not calculate transistor current, analog delay, leakage, or physical power. Run the actual commands and inspect outputs before marking a project verified.

## GitHub destination
`mission-100-verilog-projects/02-cmos-logic/project-019-cmos-2-to-1-multiplexer/`

## Verification status
**Pending verification.** These source files are prepared for execution, but the simulations have not been reported as run or passed.
