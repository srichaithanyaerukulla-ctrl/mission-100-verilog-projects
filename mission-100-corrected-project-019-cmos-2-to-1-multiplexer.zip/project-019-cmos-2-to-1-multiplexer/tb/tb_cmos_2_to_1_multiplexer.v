`timescale 1ns/1ps
module tb_cmos_mux2to1;
reg d0,d1,s; wire y; integer errors;
cmos_mux2to1 dut(.d0(d0),.d1(d1),.s(s),.y(y));
task check(input reg d0v, input reg d1v, input reg sv, input reg expected);
begin d0=d0v; d1=d1v; s=sv; #10; if(y!==expected) errors=errors+1; end endtask
initial begin errors=0;
check(0,0,0,0); check(0,1,0,0); check(1,0,0,1); check(1,1,0,1);
check(0,0,1,0); check(0,1,1,1); check(1,0,1,0); check(1,1,1,1);
if(errors==0) $display("PASS: CMOS 2:1 mux selection"); else $display("FAIL: %0d errors",errors); $finish; end
endmodule
