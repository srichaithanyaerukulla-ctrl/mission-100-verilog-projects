module cmos_mux2to1(input wire d0,d1,s, output wire y); assign y = s ? d1 : d0; endmodule
