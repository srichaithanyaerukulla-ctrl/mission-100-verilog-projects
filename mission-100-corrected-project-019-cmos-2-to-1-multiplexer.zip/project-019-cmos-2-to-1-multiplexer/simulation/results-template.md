# Simulation Results — Project 019: CMOS 2:1 Multiplexer

- Date:
- ngspice version:
- Icarus Verilog version:

## Verilog
- Command executed:
- Final testbench output:
- Passed cases:
- Failed cases:

## SPICE
- Command executed:
- Did the netlist complete without errors?
- CSV generated:
- Observed signal behavior:
- Notes/model warnings:

## Conclusion
Record observations from actual simulator output. Do not copy expected behavior as measured results.
