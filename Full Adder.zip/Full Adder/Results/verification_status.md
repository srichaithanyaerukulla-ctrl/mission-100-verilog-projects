# Verification status — Full Adder

## Current status
Not simulator-verified at packaging time. The source and self-checking testbenches are provided, and expected outputs are derived from the full-adder truth table. No actual simulator transcript or waveform is represented as completed evidence.

## Record each model after running it
| Model | Simulator/version | All 8 cases passed? | VCD inspected? | Notes |
|---|---|---|---|---|
| Switch-level | | | | |
| Gate-level | | | | |
| Dataflow | | | | |
| Behavioral | | | | |

Attach screenshots of actual simulator output and waveforms here when available.
