# Full Adder

## Project objective
Implement and verify a 1-bit full adder in four Verilog modeling styles: switch-level, gate-level, dataflow, and behavioral. Each style has its own Verilog design, self-checking testbench, schematic, and reference output file.

## 1. Full-adder theory
A full adder is a combinational digital circuit that adds three one-bit inputs: `A`, `B`, and `Cin` (carry-in). It produces a one-bit `Sum` and a one-bit `Cout` (carry-out). It is used in multi-bit adders, arithmetic logic units (ALUs), counters, and datapaths.

### Boolean equations
Define the propagate/intermediate term:

`P = A XOR B`

Then:

`Sum = P XOR Cin = A XOR B XOR Cin`

`Cout = (A AND B) OR (P AND Cin)`

Equivalent majority expression:

`Cout = (A AND B) OR (A AND Cin) OR (B AND Cin)`

The carry is 1 whenever at least two of the three inputs are 1. The sum is 1 whenever an odd number of inputs are 1.

### Truth table
| A | B | Cin | Sum | Cout |
|---:|---:|---:|---:|---:|
| 0 | 0 | 0 | 0 | 0 |
| 0 | 0 | 1 | 1 | 0 |
| 0 | 1 | 0 | 1 | 0 |
| 0 | 1 | 1 | 0 | 1 |
| 1 | 0 | 0 | 1 | 0 |
| 1 | 0 | 1 | 0 | 1 |
| 1 | 1 | 0 | 0 | 1 |
| 1 | 1 | 1 | 1 | 1 |

## 2. Four modeling styles

### Switch-level model
`Switch/full_adder_switch.v` builds CMOS NAND gates from Verilog `pmos` and `nmos` switch primitives, then connects those NAND gates to realize the full-adder equations. Each static-CMOS NAND2 uses two parallel PMOS devices in the pull-up network and two series NMOS devices in the pull-down network. The complete NAND-network implementation uses nine NAND2 blocks (36 MOS switch primitives). This is a switch-level functional/electrical abstraction, not a foundry-calibrated transistor simulation; device sizing, parasitics, and process-specific MOS models are not provided.

### Gate-level model
`Gate/full_adder_gate.v` uses built-in Verilog gate primitives such as `xor`, `and`, and `or`. The instances explicitly show the logic gates and how they connect.

### Dataflow model
`Dataflow/full_adder_dataflow.v` uses continuous `assign` statements and Boolean operators to express the equations directly. It describes logic relationships rather than an explicit gate-instance netlist.

### Behavioral model
`Behavioral/full_adder_behavioral.v` uses an `always @*` procedural block and a widened two-bit addition. The explicit zero-extension matters because Verilog expression sizing can otherwise truncate a one-bit addition result.

These models should implement the same truth table, but they describe the design at different abstraction levels. None of these RTL/switch-level files by itself is a physical layout or a process-corner-accurate analog simulation.

## 3. Project structure
- `Switch/` — switch-level design, testbench, schematic, reference output.
- `Gate/` — gate-level design, testbench, schematic, reference output.
- `Dataflow/` — dataflow design, testbench, schematic, reference output.
- `Behavioral/` — behavioral design, testbench, schematic, reference output.
- `Results/truth_table.csv` — expected truth table in CSV format.
- `Results/verification_status.md` — record your actual simulator runs.

Each model folder includes `schematic.svg` and `schematic.png`. The switch-level folder additionally contains `cmos_nand2_transistor_schematic.svg` and `.png`, showing the PMOS parallel/NMOS series CMOS NAND topology.

## 4. Run each model independently
Install Icarus Verilog (or use another compatible Verilog simulator). Run commands from the project folder.

**Switch-level**
```bash
iverilog -g2012 -o switch_sim Switch/full_adder_switch.v Switch/tb_full_adder_switch.v
vvp switch_sim
```

**Gate-level**
```bash
iverilog -g2012 -o gate_sim Gate/full_adder_gate.v Gate/tb_full_adder_gate.v
vvp gate_sim
```

**Dataflow**
```bash
iverilog -g2012 -o dataflow_sim Dataflow/full_adder_dataflow.v Dataflow/tb_full_adder_dataflow.v
vvp dataflow_sim
```

**Behavioral**
```bash
iverilog -g2012 -o behavioral_sim Behavioral/full_adder_behavioral.v Behavioral/tb_full_adder_behavioral.v
vvp behavioral_sim
```

Each testbench iterates through all eight combinations, checks `Sum` and `Cout` against an independently calculated expected result, prints each case, and ends with a PASS or FAIL summary. Each run writes a VCD waveform file in the current directory; use GTKWave to inspect it if available. The `expected_output.txt` files are **reference outputs** generated from the truth table, not captured simulator transcripts. Run the testbenches to produce and confirm actual output before marking the project verified.

## 5. What to inspect
1. Confirm all eight input patterns are covered in every model.
2. Compare the observed `Sum` and `Cout` against the truth table.
3. In GTKWave, inspect `A`, `B`, `Cin`, `Sum`, and `Cout`.
4. Confirm that the switch-level CMOS NAND network produces the same stable Boolean outputs as the other three models.
5. Record simulator/version and actual run result in `Results/verification_status.md`.

## 6. Expected learning outcomes
After completing this project, you should be able to explain full-adder Boolean equations, distinguish four Verilog modeling styles, build a CMOS NAND from switch primitives, create self-checking testbenches, interpret truth tables, and inspect digital waveforms.

**Verification status at packaging:** Not simulator-verified in this environment. The supplied testbenches and reference outputs are provided so you can run and record genuine simulation results.
