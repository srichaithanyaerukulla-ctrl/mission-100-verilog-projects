`timescale 1ns/1ps

module full_adder_behavioral(
    input wire A, input wire B, input wire Cin,
    output reg Sum, output reg Cout
);
    reg [1:0] result;

    always @* begin
        // Widen each input so the carry bit is retained.
        result = {1'b0, A} + {1'b0, B} + {1'b0, Cin};
        Sum    = result[0];
        Cout   = result[1];
    end
endmodule
