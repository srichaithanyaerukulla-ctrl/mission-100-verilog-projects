`timescale 1ns/1ps

module tb_full_adder_dataflow;
    reg A, B, Cin;
    wire Sum, Cout;
    reg [1:0] expected;
    integer i;
    integer errors;

    full_adder_dataflow dut(.A(A), .B(B), .Cin(Cin), .Sum(Sum), .Cout(Cout));

    initial begin
        errors = 0;
        $dumpfile("full_adder_dataflow.vcd");
        $dumpvars(0, tb_full_adder_dataflow);
        for (i = 0; i < 8; i = i + 1) begin
            {A, B, Cin} = i[2:0];
            #2;
            expected = {1'b0, A} + {1'b0, B} + {1'b0, Cin};
            if ({Cout, Sum} !== expected) begin
                $display("FAIL: A=%b B=%b Cin=%b | Sum=%b Cout=%b expected Sum=%b Cout=%b", A, B, Cin, Sum, Cout, expected[0], expected[1]);
                errors = errors + 1;
            end else begin
                $display("PASS: A=%b B=%b Cin=%b | Sum=%b Cout=%b", A, B, Cin, Sum, Cout);
            end
        end
        if (errors == 0)
            $display("PASS: all 8 Dataflow full-adder test cases passed.");
        else
            $display("FAIL: %0d Dataflow full-adder test case(s) failed.", errors);
        $finish;
    end
endmodule
