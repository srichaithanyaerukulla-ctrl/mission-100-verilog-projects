`timescale 1ns/1ps

module full_adder_dataflow(
    input wire A, input wire B, input wire Cin,
    output wire Sum, output wire Cout
);
    wire P;
    assign P    = A ^ B;
    assign Sum  = P ^ Cin;
    assign Cout = (A & B) | (P & Cin);
endmodule
