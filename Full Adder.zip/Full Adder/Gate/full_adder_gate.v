`timescale 1ns/1ps

module full_adder_gate(
    input wire A, input wire B, input wire Cin,
    output wire Sum, output wire Cout
);
    wire P, G, H;
    xor X1(P, A, B);
    xor X2(Sum, P, Cin);
    and A1(G, A, B);
    and A2(H, P, Cin);
    or  O1(Cout, G, H);
endmodule
