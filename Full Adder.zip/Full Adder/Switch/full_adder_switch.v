`timescale 1ns/1ps

// A static-CMOS NAND2 switch-level primitive.
// PMOS devices are in parallel; NMOS devices are in series.
module cmos_nand2(input wire a, input wire b, output wire y);
    supply1 vdd;
    supply0 gnd;
    wire nmid;

    pmos p1(y, vdd, a);
    pmos p2(y, vdd, b);
    nmos n1(nmid, gnd, a);
    nmos n2(y, nmid, b);
endmodule

// Full adder assembled from nine CMOS NAND2 blocks.
module full_adder_switch(
    input wire A, input wire B, input wire Cin,
    output wire Sum, output wire Cout
);
    wire n1, n2, n3, P;
    wire n5, n6, n7;

    // P = A XOR B using four NAND gates
    cmos_nand2 U1(.a(A),  .b(B),  .y(n1));
    cmos_nand2 U2(.a(A),  .b(n1), .y(n2));
    cmos_nand2 U3(.a(B),  .b(n1), .y(n3));
    cmos_nand2 U4(.a(n2), .b(n3), .y(P));

    // Sum = P XOR Cin; n5 is also reused for carry generation
    cmos_nand2 U5(.a(P),   .b(Cin), .y(n5));
    cmos_nand2 U6(.a(P),   .b(n5),  .y(n6));
    cmos_nand2 U7(.a(Cin), .b(n5),  .y(n7));
    cmos_nand2 U8(.a(n6),  .b(n7),  .y(Sum));

    // Cout = A*B + P*Cin = NAND(NAND(A,B), NAND(P,Cin))
    cmos_nand2 U9(.a(n1), .b(n5), .y(Cout));
endmodule
