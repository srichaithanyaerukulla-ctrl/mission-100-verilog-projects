# Design Notes — Project 019

A positive-edge-triggered D flip-flop samples D only at the rising edge of CLK and holds Q between edges. The ideal functional rule is Q(next)=D at each positive edge. Real flip-flops have setup/hold requirements, clock-to-Q delay, clock skew, and possible metastability when timing constraints are violated. This RTL includes an asynchronous active-low reset. RTL simulation checks logical behavior, not analog metastability or physical timing.

## Validation
- Run the included testbench.
- Review warnings and confirm expected state/logic transitions.
- For SPICE projects, inspect waveform and model assumptions.
