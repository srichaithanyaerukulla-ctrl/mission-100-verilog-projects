`timescale 1ns/1ps
module tb_dff_posedge_async_reset; reg clk,rst_n,d; wire q; integer e;
dff_posedge_async_reset dut(clk,rst_n,d,q); always #5 clk=~clk;
initial begin e=0;clk=0;rst_n=0;d=0;#2;if(q!==0)e=e+1;
rst_n=1;d=1;#4;if(q!==0)e=e+1;
#2;if(q!==1)e=e+1;
d=0;#3;if(q!==1)e=e+1;
#3;if(q!==0)e=e+1;
rst_n=0;#1;if(q!==0)e=e+1;
if(e==0)$display("PASS: DFF/reset");else $display("FAIL %0d",e);$finish;end endmodule