# Project 019 — Positive-Edge-Triggered D Flip-Flop

**Mission 100 Verilog Projects · Semiconductor-to-VLSI Journey · Project 019/100**

## Objective
Positive-Edge-Triggered D Flip-Flop: implement the design and verify its behavior with a self-checking Verilog testbench.

## Theory
A positive-edge-triggered D flip-flop samples D only at the rising edge of CLK and holds Q between edges. The ideal functional rule is Q(next)=D at each positive edge. Real flip-flops have setup/hold requirements, clock-to-Q delay, clock skew, and possible metastability when timing constraints are violated. This RTL includes an asynchronous active-low reset. RTL simulation checks logical behavior, not analog metastability or physical timing.

## Design approach
The RTL models functional logic or storage. It does not automatically reproduce analog transistor behavior, power, propagation delay, or metastability. Where a SPICE netlist is provided, it uses generic educational MOSFET models rather than a foundry-calibrated process model.

## Files
- `README.md` — theory and run instructions.
- `verilog/positive_edge_d_flip_flop.v` — Verilog implementation.
- `tb/tb_positive_edge_d_flip_flop.v` — self-checking testbench.
- No SPICE netlist is included because this project focuses on RTL sequential behavior.\n- `docs/design-notes.md` — design considerations.
- `simulation/results-template.md` — record actual results.

## Run Verilog
```sh
iverilog -g2012 -s tb_positive_edge_d_flip_flop -o sim_out verilog/positive_edge_d_flip_flop.v tb/tb_positive_edge_d_flip_flop.v
vvp sim_out
```

## Verification status
**Pending verification.** The files are packaged for execution, but no test or SPICE result is claimed until you run the simulator and inspect its output.
