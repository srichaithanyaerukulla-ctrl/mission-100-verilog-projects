# Project 020 — 4-Bit Register with Enable and Reset

**Mission 100 Verilog Projects · Semiconductor-to-VLSI Journey · Project 020/100**

## Objective
4-Bit Register with Enable and Reset: implement the design and verify its behavior with a self-checking Verilog testbench.

## Theory
A register groups flip-flops to store a multi-bit word. This 4-bit register captures D on the rising clock edge when EN=1 and holds its previous word when EN=0. An asynchronous active-low reset clears Q to 0000 independently of the clock. Registers are used in datapaths, pipelines, counters, and control logic. Synthesis may map the enable to an integrated-enable flip-flop or a mux before ordinary flip-flops.

## Design approach
The RTL models functional logic or storage. It does not automatically reproduce analog transistor behavior, power, propagation delay, or metastability. Where a SPICE netlist is provided, it uses generic educational MOSFET models rather than a foundry-calibrated process model.

## Files
- `README.md` — theory and run instructions.
- `verilog/four_bit_register_enable_reset.v` — Verilog implementation.
- `tb/tb_four_bit_register_enable_reset.v` — self-checking testbench.
- No SPICE netlist is included because this project focuses on RTL sequential behavior.\n- `docs/design-notes.md` — design considerations.
- `simulation/results-template.md` — record actual results.

## Run Verilog
```sh
iverilog -g2012 -s tb_four_bit_register_enable_reset -o sim_out verilog/four_bit_register_enable_reset.v tb/tb_four_bit_register_enable_reset.v
vvp sim_out
```

## Verification status
**Pending verification.** The files are packaged for execution, but no test or SPICE result is claimed until you run the simulator and inspect its output.
