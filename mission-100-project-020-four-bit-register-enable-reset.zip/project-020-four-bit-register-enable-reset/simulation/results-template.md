# Results — Project 020: 4-Bit Register with Enable and Reset

- Date/tool versions:
- Verilog command:
- Final testbench output:
- Passed checks:
- Failed checks:

## Conclusion
Summarize actual outputs; do not report expected behavior as measured results.
