`timescale 1ns/1ps
module tb_register4_en_reset; reg clk,rst_n,en; reg [3:0] d; wire [3:0] q; integer e;
register4_en_reset dut(clk,rst_n,en,d,q); always #5 clk=~clk;
initial begin e=0;clk=0;rst_n=0;en=0;d=0;#2;if(q!==0)e=e+1;
rst_n=1;en=1;d=4'b1010;#8;if(q!==4'b1010)e=e+1;
en=0;d=4'b0101;#10;if(q!==4'b1010)e=e+1;
en=1;#10;if(q!==4'b0101)e=e+1;
rst_n=0;#1;if(q!==0)e=e+1;
if(e==0)$display("PASS: register load/hold/reset");else $display("FAIL %0d",e);$finish;end endmodule