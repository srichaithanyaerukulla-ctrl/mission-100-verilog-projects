# Design Notes — Project 020

A register groups flip-flops to store a multi-bit word. This 4-bit register captures D on the rising clock edge when EN=1 and holds its previous word when EN=0. An asynchronous active-low reset clears Q to 0000 independently of the clock. Registers are used in datapaths, pipelines, counters, and control logic. Synthesis may map the enable to an integrated-enable flip-flop or a mux before ordinary flip-flops.

## Validation
- Run the included testbench.
- Review warnings and confirm expected state/logic transitions.
- For SPICE projects, inspect waveform and model assumptions.
