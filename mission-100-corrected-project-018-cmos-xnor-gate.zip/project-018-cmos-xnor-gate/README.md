# Project 018 — CMOS XNOR Gate

**Mission 100 Verilog Projects · CMOS Logic Design · Project 018/100**

## Objective
Study **Complementary logic** by understanding the transistor-level circuit, writing a functional Verilog model, and checking its truth table with a self-checking testbench.

## Theory
XNOR is the complement of XOR: `Y = ~(A ⊕ B)`. It produces HIGH when the inputs are equal and LOW when they differ. XNOR is useful in equality comparators and equivalence checking.

The implementation uses a NAND-based XOR network followed by a CMOS inverter. This demonstrates complementary logic and the cost of restoring output polarity. As with other transistor-level examples, actual switching delay and power depend on device sizing, parasitic capacitances, load, and the process model.

## Expected behavior
Output is HIGH for 00 and 11; LOW for 01 and 10.

## Files
- `README.md` — theory and run guide.
- `verilog/cmos_xnor_gate.v` — Verilog implementation.
- `tb/tb_cmos_xnor_gate.v` — self-checking testbench.
- `spice/cmos_xnor_gate.cir` — illustrative transistor-level SPICE netlist.
- `docs/design-notes.md` — design considerations and limitations.
- `simulation/results-template.md` — record actual results.
- `.gitignore` — ignores generated outputs.

## Run Verilog
Run from this project folder:
```sh
iverilog -g2012 -s tb_cmos_xnor_gate -o sim_out verilog/cmos_xnor_gate.v tb/tb_cmos_xnor_gate.v
vvp sim_out
```

## Run SPICE
Requires ngspice:
```sh
ngspice -b spice/cmos_xnor_gate.cir
```
Inspect the simulator output and CSV file. SPICE syntax and model behavior may vary by simulator version.

## Model and verification limits
The SPICE examples use generic Level-1 MOSFET models with illustrative parameters; they are not vendor- or foundry-calibrated. The RTL modules represent Boolean functionality and do not calculate transistor current, analog delay, leakage, or physical power. Run the actual commands and inspect outputs before marking a project verified.

## GitHub destination
`mission-100-verilog-projects/02-cmos-logic/project-018-cmos-xnor-gate/`

## Verification status
**Pending verification.** These source files are prepared for execution, but the simulations have not been reported as run or passed.
