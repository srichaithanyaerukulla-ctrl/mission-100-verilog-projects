# Design Notes — Project 018: CMOS XNOR Gate

## Design theory
XNOR is the complement of XOR: `Y = ~(A ⊕ B)`. It produces HIGH when the inputs are equal and LOW when they differ. XNOR is useful in equality comparators and equivalence checking.

The implementation uses a NAND-based XOR network followed by a CMOS inverter. This demonstrates complementary logic and the cost of restoring output polarity. As with other transistor-level examples, actual switching delay and power depend on device sizing, parasitic capacitances, load, and the process model.

## Expected behavior
Output is HIGH for 00 and 11; LOW for 01 and 10.

## Implementation cautions
## Model and verification limits
The SPICE examples use generic Level-1 MOSFET models with illustrative parameters; they are not vendor- or foundry-calibrated. The RTL modules represent Boolean functionality and do not calculate transistor current, analog delay, leakage, or physical power. Run the actual commands and inspect outputs before marking a project verified.
