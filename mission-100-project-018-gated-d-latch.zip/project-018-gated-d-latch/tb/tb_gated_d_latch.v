`timescale 1ns/1ps
module tb_gated_d_latch; reg d,en; wire q; integer e;
gated_d_latch dut(d,en,q);
initial begin e=0;
en=1;d=0;#10;if(q!==0)e=e+1;
d=1;#10;if(q!==1)e=e+1;
en=0;d=0;#10;if(q!==1)e=e+1;
d=1;#10;if(q!==1)e=e+1;
if(e==0)$display("PASS: D latch transparent/hold");else $display("FAIL %0d",e);$finish;end endmodule