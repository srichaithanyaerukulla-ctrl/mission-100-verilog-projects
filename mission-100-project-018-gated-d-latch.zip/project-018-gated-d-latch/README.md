# Project 018 — Gated D Latch

**Mission 100 Verilog Projects · Semiconductor-to-VLSI Journey · Project 018/100**

## Objective
Gated D Latch: implement the design and verify its behavior with a self-checking Verilog testbench.

## Theory
A gated D latch is level-sensitive. When EN=1 it is transparent and Q follows D; when EN=0 it holds the previous value. It is not edge-triggered, so data can propagate during the entire active enable level. The behavioral RTL intentionally omits an assignment when EN is low, inferring storage. Latch transparency must be considered in timing analysis.

## Design approach
The RTL models functional logic or storage. It does not automatically reproduce analog transistor behavior, power, propagation delay, or metastability. Where a SPICE netlist is provided, it uses generic educational MOSFET models rather than a foundry-calibrated process model.

## Files
- `README.md` — theory and run instructions.
- `verilog/gated_d_latch.v` — Verilog implementation.
- `tb/tb_gated_d_latch.v` — self-checking testbench.
- No SPICE netlist is included because this project focuses on RTL sequential behavior.\n- `docs/design-notes.md` — design considerations.
- `simulation/results-template.md` — record actual results.

## Run Verilog
```sh
iverilog -g2012 -s tb_gated_d_latch -o sim_out verilog/gated_d_latch.v tb/tb_gated_d_latch.v
vvp sim_out
```

## Verification status
**Pending verification.** The files are packaged for execution, but no test or SPICE result is claimed until you run the simulator and inspect its output.
