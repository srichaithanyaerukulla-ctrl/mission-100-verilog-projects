# Design Notes — Project 018

A gated D latch is level-sensitive. When EN=1 it is transparent and Q follows D; when EN=0 it holds the previous value. It is not edge-triggered, so data can propagate during the entire active enable level. The behavioral RTL intentionally omits an assignment when EN is low, inferring storage. Latch transparency must be considered in timing analysis.

## Validation
- Run the included testbench.
- Review warnings and confirm expected state/logic transitions.
- For SPICE projects, inspect waveform and model assumptions.
